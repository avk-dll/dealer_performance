What goes where (all optional except the gold file):

gold/      gold_dealer_features.csv — dealer list and performance (shipped with the app).

outputs/   The segmentation pipeline's result CSVs, exactly as the notebook writes them:
             v2_final_all_<timestamp>.csv, v2_final_<MARKET>_<timestamp>.csv, debug_<MARKET>_<timestamp>.csv
           Until files are added here, the app shows no segments (only gold performance).
           The newest run (timestamp in the file name) is shown.

models/    The saved GMM model file(s) (.pkl) from the pipeline. Either one file per
           market with the market code in the name (e.g. ..._US_OE_....pkl) or one file
           holding all markets (a dict keyed by market code). Each entry must contain the
           fitted GaussianMixture and StandardScaler. Used for predictions only.

catalog/   Optional extra reference CSVs joined on SellingParty_ID + Market.
