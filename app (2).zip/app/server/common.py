"""Helpers shared by the routers: filters, JSON cleaning, descriptive stats."""

from typing import List, Optional

import numpy as np
import pandas as pd
from fastapi import HTTPException, Query

from . import dataset, settings


class Filters:
    """Global filters sent by the UI on every request. Top bar: country, bu, market, segment.
    Advanced Filters page: parties (market:dealer_id), momentum, min_nbv, loss (loss-making only)."""

    def __init__(self, market: Optional[str] = Query(None), country: Optional[str] = Query(None),
                 bu: Optional[str] = Query(None), segment: Optional[str] = Query(None),
                 parties: Optional[str] = Query(None), momentum: Optional[str] = Query(None),
                 min_nbv: Optional[float] = Query(None, ge=0), loss: bool = Query(False)):
        self.markets = _split(market)
        self.countries = _split(country)
        self.bus = _split(bu)
        self.segments = _split(segment)
        self.parties = _split(parties)
        self.momentum = _split(momentum)
        self.min_nbv = min_nbv
        self.loss = loss

    def apply(self, df: pd.DataFrame) -> pd.DataFrame:
        if self.markets:
            df = df[df["market"].isin(self.markets)]
        if self.countries:
            df = df[df["country"].isin(self.countries)]
        if self.bus:
            df = df[df["business_unit"].isin(self.bus)]
        if self.segments and "segment_view" in df:
            df = df[df["segment_view"].isin(self.segments)]
        if self.parties and "party_key" in df:
            df = df[df["party_key"].isin(self.parties)]
        if self.momentum and "momentum" in df:
            df = df[df["momentum"].isin(self.momentum)]
        if self.min_nbv:
            df = df[df["NBV_EUR"] >= self.min_nbv]
        if self.loss:
            df = df[df["Risk_Adjusted_Margin"] < 0]
        return df


def gold_or_404():
    ds = dataset.get()
    if ds.gold is None:
        raise HTTPException(404, "Gold dealer features are not available (data/gold/gold_dealer_features.csv).")
    return ds


def _split(v: Optional[str]) -> List[str]:
    return [x for x in (v or "").split(",") if x]


def clean(obj):
    if isinstance(obj, dict):
        return {k: clean(v) for k, v in obj.items()}
    if isinstance(obj, (list, tuple)):
        return [clean(v) for v in obj]
    if isinstance(obj, (np.integer,)):
        return int(obj)
    if isinstance(obj, (float, np.floating)):
        f = float(obj)
        return None if (np.isnan(f) or np.isinf(f)) else f
    if isinstance(obj, np.bool_):
        return bool(obj)
    if obj is pd.NA or obj is pd.NaT:
        return None
    return obj


def segments() -> List[str]:
    return settings.contract()["segments"]["order"]


def quantiles(s: pd.Series) -> Optional[dict]:
    s = pd.to_numeric(s, errors="coerce").replace([np.inf, -np.inf], np.nan).dropna()
    if s.empty:
        return None
    q = s.quantile([0.1, 0.3, 0.5, 0.7, 0.9])
    return {"p10": q[0.1], "p30": q[0.3], "median": q[0.5], "p70": q[0.7], "p90": q[0.9], "n": int(len(s))}


def verdict(value, q: Optional[dict], favour: str) -> str:
    if value is None or q is None or pd.isna(value):
        return "n/a"
    if favour == "lower":
        return "good" if value <= q["p30"] else ("poor" if value >= q["p70"] else "average")
    return "good" if value >= q["p70"] else ("poor" if value <= q["p30"] else "average")


def vs_py(d: pd.DataFrame) -> Optional[float]:
    """Volume change on the prior year for a group of dealers (sum Y1 / sum Y2 − 1)."""
    y2 = d["nbv_y2"].sum() if "nbv_y2" in d else 0
    return float(d["nbv_y1"].sum() / y2 - 1) if y2 and y2 > 0 else None


def group_summary(d: pd.DataFrame, total_nbv: float, total_n: int) -> dict:
    """The headline figures shown for a segment, a market or the whole portfolio."""
    n, nbv = len(d), float(d["NBV_EUR"].sum())
    ram = float(d["Risk_Adjusted_Margin"].sum())
    return {"dealers": int(n), "dealer_share": n / total_n * 100 if total_n else None,
            "nbv": nbv, "nbv_share": nbv / total_nbv * 100 if total_nbv else None,
            "avg_nbv": nbv / n if n else None, "nbv_vs_py": vs_py(d),
            "ram": ram, "ram_per_nbv": ram / nbv if nbv else None,
            "median_pd": float(d["PD_Rate"].median()) if "PD_Rate" in d and d["PD_Rate"].notna().any() else None,
            "neg_ram_share": float((d["Risk_Adjusted_Margin"] < 0).mean() * 100) if n else None}
