"""The two data sets the app shows, both read-only and cached.

gold       The gold dealer features (always present): dealer list, performance
           metrics, current segment. Also the input for predictions.
published  Segmentation results exported by the data science pipeline — only
           once they have been uploaded (data/outputs) or configured (UC table).
           The latest run is used; debug files, catalog CSVs and the gold data
           fill in columns the final file does not carry.
"""
from __future__ import annotations

import logging
import threading
import time
from dataclasses import dataclass, field
from typing import Dict, List, Optional

import numpy as np
import pandas as pd

from . import settings
from .engine.features import prepare_gold
from .sources import Frame, csv_signature, read_outputs

log = logging.getLogger(__name__)


@dataclass
class Table:
    df: pd.DataFrame                 # canonical columns (see normalise)
    metrics: List[dict]
    dimensions: List[str]
    coverage: Dict[str, Optional[str]]


@dataclass
class Published(Table):
    run_timestamp: Optional[str] = None
    files: List[str] = field(default_factory=list)
    has_archetype: bool = False


@dataclass
class Dataset:
    gold: Optional[Table]
    gold_raw: Optional[pd.DataFrame]   # prepared gold table with all original columns
    published: Optional[Published]
    files: List[dict]
    errors: List[str]
    loaded_at: float


# ── normalisation (contract-driven) ──────────────────────────────────────────

def _first(df: pd.DataFrame, candidates: List[str]) -> Optional[str]:
    return next((c for c in candidates if c in df.columns), None)


def _num(s: pd.Series) -> pd.Series:
    return pd.to_numeric(s, errors="coerce")


def normalise(raw: pd.DataFrame):
    c = settings.contract()
    df = pd.DataFrame(index=raw.index)
    coverage: Dict[str, Optional[str]] = {}
    for fld, cands in c["fields"].items():
        col = _first(raw, cands)
        coverage[fld] = col
        df[fld] = raw[col] if col else np.nan

    if coverage["market"] is None and coverage["country"] and coverage["business_unit"]:
        df["market"] = raw[coverage["country"]].astype(str).str.strip() + "_" + raw[coverage["business_unit"]].astype(str).str.strip()
    split = df["market"].astype(str).str.split("_", n=1, expand=True)
    if coverage["country"] is None and split.shape[1] == 2:
        df["country"] = split[0]
    if coverage["business_unit"] is None and split.shape[1] == 2:
        df["business_unit"] = split[1]

    df["dealer_id"] = df["dealer_id"].map(
        lambda v: (str(int(float(v))) if isinstance(v, (int, float, np.integer, np.floating)) and pd.notna(v) and float(v).is_integer()
                   else (str(v) if pd.notna(v) else None)))
    for fld in ("confidence", "composite_score", "cluster_confidence"):
        df[fld] = _num(df[fld])

    nbv_col = _first(raw, ["NBV_EUR"])
    nbv = _num(raw[nbv_col]) if nbv_col else None
    nbv_safe = nbv.replace(0, np.nan) if nbv is not None else None
    metrics = []
    for m in c["metrics"]:
        col = _first(raw, m["columns"])
        values = _num(raw[col]) if col else None
        derived = False
        if values is None and nbv_safe is not None:
            k = m["key"]
            if k == "RAM_per_NBV" and "Risk_Adjusted_Margin" in raw:
                values, derived = _num(raw["Risk_Adjusted_Margin"]) / nbv_safe, True
            elif k == "PD_Rate" and "PD_Weighted_Sum" in raw:
                values, derived = _num(raw["PD_Weighted_Sum"]) / nbv_safe, True
            elif k == "LGD_Rate" and "LGD_Weighted_Sum" in raw:
                values, derived = _num(raw["LGD_Weighted_Sum"]) / nbv_safe, True
            elif k == "Avg_Deal_Size" and "Distinct_Contracts" in raw:
                values, derived = nbv / _num(raw["Distinct_Contracts"]).replace(0, np.nan), True
            elif k == "NBV_vs_PY" and "Y2_NBV" in raw:
                values, derived = nbv / _num(raw["Y2_NBV"]).where(_num(raw["Y2_NBV"]) > 0) - 1, True
        if values is None and m["key"] == "Expected_Loss_Rate" and "PD_Rate" in df and "LGD_Rate" in df:
            values, derived = df["PD_Rate"] * df["LGD_Rate"], True
        if values is not None:
            df[m["key"]] = values.replace([np.inf, -np.inf], np.nan)
            metrics.append({**{k: v for k, v in m.items() if k != "columns"}, "source_column": col or "derived", "derived": derived})

    # Volume history (Y3 = two years ago, Y2 = prior year, Y1 = latest year) for trend views.
    for key, cands in (("nbv_y3", ["Y3_NBV"]), ("nbv_y2", ["Y2_NBV"]), ("nbv_y1", ["NBV_EUR", "Y1_NBV"])):
        col = _first(raw, cands)
        df[key] = _num(raw[col]) if col else np.nan

    # Published Dim_ columns keep the pipeline's names; some are shown under a clearer label
    # (the pipeline's "Profitability" is scored on risk-adjusted margin).
    prefix = c.get("dimension_prefix", "Dim_")
    labels = c.get("dimension_labels", {})
    dims = []
    for col in raw.columns:
        if col.startswith(prefix):
            d = labels.get(col[len(prefix):], col[len(prefix):])
            if d not in dims:
                dims.append(d)
                df[f"dim:{d}"] = _num(raw[col])

    order = c["segments"]["order"]
    df["segment"] = df["segment"].where(df["segment"].isin(order))
    df["current_segment"] = df["current_segment"].where(df["current_segment"].isin(order))
    df["changed"] = df["segment"].notna() & df["current_segment"].notna() & (df["segment"] != df["current_segment"])
    for fld in ("dealer_name", "rationale", "source", "archetype"):
        df[fld] = df[fld].where(df[fld].notna(), None)
    return df, coverage, metrics, dims


# ── view columns used by the global filters ─────────────────────────────────

UNASSIGNED = "Unassigned"
FLAT_BAND = 0.02   # a change within ±2% on the prior year counts as flat


def momentum(change: pd.Series) -> pd.Series:
    """Growing / Flat / Declining on the prior year; New when there was no prior-year volume."""
    out = pd.Series("New", index=change.index, dtype=object)
    out[change > FLAT_BAND] = "Growing"
    out[change.between(-FLAT_BAND, FLAT_BAND)] = "Flat"
    out[change < -FLAT_BAND] = "Declining"
    return out


def add_views(gold: pd.DataFrame, published: Optional[pd.DataFrame]) -> pd.DataFrame:
    """segment_view: the model's published segment when results exist (dealers the model
    did not segment are Unassigned), otherwise the current segmentation."""
    g = gold.copy()
    if published is not None:
        seg = published[["dealer_id", "market", "segment"]].rename(columns={"segment": "_pub"})
        g = g.merge(seg, on=["dealer_id", "market"], how="left")
        g["segment_view"] = g.pop("_pub").fillna(UNASSIGNED)
    else:
        g["segment_view"] = g["current_segment"].fillna(UNASSIGNED)
    g["momentum"] = momentum(g["NBV_vs_PY"])
    g["party_key"] = g["market"].astype(str) + ":" + g["dealer_id"].astype(str)
    return g


# ── building ─────────────────────────────────────────────────────────────────

def _ts_key(f: Frame) -> str:
    return f.timestamp or (f.modified or "").replace("-", "").replace(":", "").replace("T", "_")[:15]


def _combine(frames: List[Frame]) -> Optional[pd.DataFrame]:
    if not frames:
        return None
    alls = [f for f in frames if f.scope == "all"]
    return pd.concat([f.df for f in (alls[:1] if alls else frames)], ignore_index=True)


def _keys(df: pd.DataFrame) -> List[str]:
    if "Market" not in df.columns and {"ConsolidationCountryCode", "Business_Unit_Code"} <= set(df.columns):
        df["Market"] = df["ConsolidationCountryCode"].astype(str) + "_" + df["Business_Unit_Code"].astype(str)
    return [k for k in settings.contract()["catalog"]["join_keys"] if k in df.columns]


def _fill_from(base: pd.DataFrame, extra: pd.DataFrame) -> pd.DataFrame:
    keys = _keys(base)
    if not keys or not set(keys) <= set(_keys(extra)):
        return base
    new_cols = [c for c in extra.columns if c not in base.columns and c not in keys]
    if not new_cols:
        return base
    extra = extra[keys + new_cols].drop_duplicates(subset=keys).copy()
    for k in keys:
        base[k] = base[k].astype(str).str.replace(r"\.0$", "", regex=True)
        extra[k] = extra[k].astype(str).str.replace(r"\.0$", "", regex=True)
    return base.merge(extra, on=keys, how="left")


def _load_gold() -> Optional[pd.DataFrame]:
    if not settings.GOLD_PATH.exists():
        return None
    return prepare_gold(pd.read_csv(settings.GOLD_PATH, low_memory=False))


def build() -> Dataset:
    errors: List[str] = []
    gold_raw, gold = None, None
    try:
        gold_raw = _load_gold()
        if gold_raw is not None:
            gdf, cov, mets, _ = normalise(gold_raw)
            gold = Table(df=gdf[gdf["dealer_id"].notna()].reset_index(drop=True), metrics=mets, dimensions=[], coverage=cov)
    except Exception as e:
        errors.append(f"Gold features: {e}")
        log.exception("Could not load gold features")

    frames = read_outputs()
    seg_cols = settings.contract()["fields"]["segment"]
    outputs = [f for f in frames if f.kind != "catalog" and _first(f.df, seg_cols)]
    catalogs = [f for f in frames if f.kind == "catalog"]

    published = None
    used: set = set()
    if outputs:
        latest = max(_ts_key(f) for f in outputs)
        run = [f for f in outputs if _ts_key(f) == latest]
        base = _combine([f for f in run if f.kind == "final"])
        debug = _combine([f for f in run if f.kind == "debug"])
        if base is None:
            base, debug = debug, None
        if debug is not None:
            base = _fill_from(base, debug)
        for cat in catalogs:
            base = _fill_from(base, cat.df.copy())
        if gold_raw is not None:
            base = _fill_from(base, gold_raw.copy())
        try:
            df, coverage, metrics, dims = normalise(base)
            df = df[df["dealer_id"].notna() & df["segment"].notna()].drop_duplicates(subset=["dealer_id", "market"], keep="last")
            published = Published(df=df.reset_index(drop=True), metrics=metrics, dimensions=dims, coverage=coverage,
                                  run_timestamp=run[0].timestamp or latest, files=[f.name for f in run],
                                  has_archetype=bool(df["archetype"].notna().any()))
            used = {f.name for f in run}
        except Exception as e:
            errors.append(f"Published results: {e}")
            log.exception("Could not read published results")

    if gold is not None:
        gold.df = add_views(gold.df, published.df if published is not None else None)
    if published is not None:
        pdf = published.df
        pdf["segment_view"] = pdf["segment"]
        pdf["momentum"] = momentum(pdf["NBV_vs_PY"]) if "NBV_vs_PY" in pdf else "New"
        pdf["party_key"] = pdf["market"].astype(str) + ":" + pdf["dealer_id"].astype(str)
        for k in ("nbv_y1", "nbv_y2", "nbv_y3"):
            if k not in pdf:
                pdf[k] = np.nan

    files = [{"name": f.name, "kind": f.kind, "timestamp": f.timestamp, "rows": int(len(f.df)),
              "used": f.name in used or f.kind == "catalog"} for f in frames]
    return Dataset(gold=gold, gold_raw=gold_raw, published=published, files=files, errors=errors, loaded_at=time.time())


# ── cache ────────────────────────────────────────────────────────────────────

_lock = threading.Lock()
_state: Dict[str, object] = {"ds": None, "sig": None, "checked": 0.0}


def _signature():
    gold = settings.GOLD_PATH.stat().st_mtime if settings.GOLD_PATH.exists() else None
    if settings.DATA_SOURCE == "csv":
        return (gold, csv_signature())
    return (gold, int(time.time() // max(settings.REFRESH_SECONDS, 1)))


def get() -> Dataset:
    with _lock:
        now = time.time()
        if _state["ds"] is not None and now - float(_state["checked"]) < settings.REFRESH_SECONDS:
            return _state["ds"]  # type: ignore[return-value]
        sig = _signature()
        if _state["ds"] is None or sig != _state["sig"]:
            _state["ds"] = build()
            _state["sig"] = sig
        _state["checked"] = now
        return _state["ds"]  # type: ignore[return-value]


def reload() -> Dataset:
    with _lock:
        _state["ds"] = None
        _state["checked"] = 0.0
    return get()
