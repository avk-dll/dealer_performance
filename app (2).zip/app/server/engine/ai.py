"""AI segment assignment for one dealer, using the model's own prompt
(6 dimensions, market benchmarks, 4 calibration examples) through the
Databricks Model Serving endpoint. Authentication is the app's service
principal on Databricks, or DATABRICKS_HOST/TOKEN locally."""
from __future__ import annotations

import json
import logging
import re
import threading
from typing import Optional, Tuple

from .. import settings

log = logging.getLogger(__name__)
SEGMENTS = ["Cherish", "Grow", "Maintain", "Monitor"]


def system_prompt(cfg: dict, label: str, bench_text: str) -> str:
    dims = cfg["dimension_order"]
    seg_defs = "\n".join(
        f"  - {name}: {d['definition']}\n" + "\n".join(f"    {dim}: {d['criteria'][dim]}" for dim in dims) + f"\n    Action: {d['action']}"
        for name, d in cfg["segment_definitions"].items())
    return f"""You are a senior DLL portfolio analyst assigning dealers in market {label} to exactly one segment.

SEGMENTS:
{seg_defs}

MARKET {label} BENCHMARKS:
{bench_text}

DIMENSION SCORES: 6 ratios to market median (1.0=median). All scored so higher=better. Risk is inverted (higher score=lower default risk). Thresholds: P30=weak, P70=strong.

RULES:
1. Assign from {SEGMENTS} only.
2. Use ALL SIX dimensions holistically — Risk Adjusted Margin, Ancillary Income, Volume, Risk, Growth, Relationship Depth.
3. Judge against benchmarks only. No quota. Do not compare dealers.
4. Mention outliers explicitly.
5. Negative RAM is a strong Monitor signal.
6. Confidence 0.9+ only when all dimensions clearly agree.

FEW-SHOT EXAMPLES:

Example 1 — CHERISH:
Input: {{"dealer_id":99901,"dimension_scores":{{"Risk Adjusted Margin":1.45,"Ancillary Income":1.20,"Volume":1.62,"Risk":1.31,"Growth":1.08,"Relationship Depth":1.15}},"raw_metrics":{{"nbv_eur":{{"value":"€4.2M","verdict":"good"}},"ram_per_nbv":{{"value":"5.8%","verdict":"good"}},"pd":{{"value":"1.1%","verdict":"good"}},"growth_consistency":{{"value":"1.00","verdict":"good"}}}}}}
Output: [{{"dealer_id":99901,"segment":"Cherish","confidence":0.93,"rationale":"All six dimensions above median — €4.2M NBV (good), 5.8% RAM/NBV (good), 1.1% PD (good), consistent growth (1.0). Crown-jewel relationship."}}]

Example 2 — GROW:
Input: {{"dealer_id":99902,"dimension_scores":{{"Risk Adjusted Margin":0.95,"Ancillary Income":1.05,"Volume":1.18,"Risk":1.05,"Growth":1.52,"Relationship Depth":1.22}},"raw_metrics":{{"nbv_cagr":{{"value":"38%","verdict":"good"}},"growth_consistency":{{"value":"1.00","verdict":"good"}},"engagement_retention":{{"value":"0.88","verdict":"good"}}}}}}
Output: [{{"dealer_id":99902,"segment":"Grow","confidence":0.85,"rationale":"Strong consistent growth (38% CAGR, consistency 1.0) and deep relationship (0.88 retention) with acceptable risk."}}]

Example 3 — MAINTAIN:
Input: {{"dealer_id":99903,"dimension_scores":{{"Risk Adjusted Margin":1.02,"Ancillary Income":0.98,"Volume":0.95,"Risk":0.98,"Growth":0.91,"Relationship Depth":1.01}},"raw_metrics":{{"nbv_eur":{{"value":"€420K","verdict":"average"}},"growth_consistency":{{"value":"0.50","verdict":"average"}}}}}}
Output: [{{"dealer_id":99903,"segment":"Maintain","confidence":0.82,"rationale":"All six dimensions near median — stable relationship needing efficient service."}}]

Example 4 — MONITOR:
Input: {{"dealer_id":99904,"dimension_scores":{{"Risk Adjusted Margin":0.62,"Ancillary Income":0.55,"Volume":0.48,"Risk":0.71,"Growth":0.55,"Relationship Depth":0.63}},"raw_metrics":{{"pd":{{"value":"4.1%","verdict":"poor","outlier":"high"}},"growth_consistency":{{"value":"0.00","verdict":"poor"}}}}}}
Output: [{{"dealer_id":99904,"segment":"Monitor","confidence":0.91,"rationale":"All six dimensions below median — 4.1% PD (outlier-high), declining on both year-pairs (consistency 0.0). Elevated risk."}}]

Return JSON array only: [{{"dealer_id":<int>,"segment":"<Cherish|Grow|Maintain|Monitor>","confidence":<0-1>,"rationale":"<one sentence citing figures>"}}]"""


class _Client:
    def __init__(self):
        self._w = None
        self._lock = threading.Lock()
        self.reason = "not initialised"

    def available(self) -> Tuple[bool, str]:
        if not settings.USE_LLM:
            return False, "AI explanations are switched off (USE_LLM=false)."
        with self._lock:
            if self._w is None:
                try:
                    from databricks.sdk import WorkspaceClient
                    self._w = WorkspaceClient()
                    self.reason = "ok"
                except Exception as e:
                    self.reason = f"AI service not configured: {str(e).splitlines()[0][:160]}"
                    return False, self.reason
        return True, "ok"

    def chat(self, system: str, user: str) -> Tuple[Optional[str], str]:
        ok, reason = self.available()
        if not ok:
            return None, reason
        from databricks.sdk.service.serving import ChatMessage, ChatMessageRole
        llm = settings.model_config()["llm"]
        try:
            resp = self._w.serving_endpoints.query(
                name=llm["endpoint"],
                messages=[ChatMessage(role=ChatMessageRole.SYSTEM, content=system),
                          ChatMessage(role=ChatMessageRole.USER, content=user)],
                max_tokens=int(llm.get("max_tokens", 2000)), temperature=float(llm.get("temperature", 0.1)))
            return resp.choices[0].message.content, "ok"
        except Exception as e:
            log.warning("LLM call failed: %s", e)
            return None, f"AI service call failed: {str(e).splitlines()[0][:160]}"


client = _Client()


def _extract(text: Optional[str]):
    if not text:
        return None
    for pat in (r"\[.*\]", r"\{.*\}"):
        m = re.search(pat, text, re.DOTALL)
        if m:
            try:
                return json.loads(m.group())
            except json.JSONDecodeError:
                pass
    return None


def assign(system: str, payload: dict) -> Tuple[Optional[dict], str]:
    """Returns ({segment, confidence, rationale} | None, status message)."""
    retries = int(settings.model_config()["llm"].get("max_retries", 2))
    user = json.dumps({"market": payload.get("market"), "dealers": [payload]}, default=str)
    reason = "no answer"
    for _ in range(retries + 1):
        text, reason = client.chat(system, user)
        if text is None and reason != "ok":
            if "switched off" in reason or "not configured" in reason:
                break
            continue
        parsed = _extract(text)
        if isinstance(parsed, dict):
            parsed = parsed.get("assignments", [parsed])
        if isinstance(parsed, list):
            for item in parsed:
                try:
                    seg = str(item["segment"]).strip()
                    if seg in SEGMENTS:
                        return {"segment": seg,
                                "confidence": min(max(float(item.get("confidence", 0.5)), 0.0), 1.0),
                                "rationale": str(item.get("rationale", ""))[:600]}, "ok"
                except (KeyError, TypeError, ValueError):
                    continue
        reason = "The AI answer could not be read."
    return None, reason
