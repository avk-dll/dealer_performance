"""Gold-table preparation and feature engineering.

prepare_gold() derives Market, PD_Weighted, LGD_Weighted and
Growth_Consistency from the gold CSV produced by the gold data pipeline.

engineer_features() applies the gold feature formulas to a single dealer so a new
or hypothetical dealer can be scored against a saved version.
"""
from __future__ import annotations

from typing import Dict, Iterable

import numpy as np
import pandas as pd

ID_COLUMNS = ["SellingParty_ID", "ConsolidationCountryCode", "Business_Unit_Code", "Market"]

# Silver-level columns (yearly sums from the gold data pipeline).
RAW_COLUMNS = [
    "NBV_EUR", "Gross_Profit", "Risk_Adjusted_Margin", "Booked_Residual_Total",
    "Upfront_Fees", "Insurance_Income", "PD_Weighted_Sum", "LGD_Weighted_Sum",
    "Term_Weighted", "Distinct_Contracts", "Active_Periods", "Y2_NBV", "Y3_NBV",
    "FMV_NBV", "DealerDirect_NBV", "Current_Exposure", "Peak_Exposure",
]

# Gold-level engineered features (already P1-P99 clipped in the CSV).
GOLD_FEATURES = [
    "GP_Eff_log", "RAM_eff_log", "Fee_Eff_log", "Residual_Exp_log", "FMV_Eff_log",
    "DealerDirect_Eff_log", "UpfrontFees_Eff_log", "Insurance_Eff_log", "Expected_Loss",
    "log_NBV", "log_Contracts", "NBV_CAGR", "Engagement_Decay", "Term_Avg", "Avg_Deal_Size",
]

# Derived when the gold table is loaded.
DERIVED_FEATURES = ["PD_Weighted", "LGD_Weighted", "Growth_Consistency"]

REQUIRED_COLUMNS = (
    ["SellingParty_ID", "ConsolidationCountryCode", "Business_Unit_Code"]
    + RAW_COLUMNS
    + [f for f in GOLD_FEATURES if f != "UpfrontFees_Eff_log"]
)

FEATURE_LABELS = {
    "RAM_eff_log": "RAM efficiency (log)",
    "GP_Eff_log": "GP efficiency (log)",
    "Fee_Eff_log": "Fee efficiency (log)",
    "UpfrontFees_Eff_log": "Upfront fee efficiency (log)",
    "Insurance_Eff_log": "Insurance efficiency (log)",
    "FMV_Eff_log": "FMV reliance (log)",
    "DealerDirect_Eff_log": "Dealer-direct reliance (log)",
    "Residual_Exp_log": "Residual exposure (log)",
    "Expected_Loss": "Expected loss (PD x LGD)",
    "log_NBV": "NBV scale (log)",
    "log_Contracts": "Contract count (log)",
    "Avg_Deal_Size": "Average deal size",
    "PD_Weighted": "PD (NBV-weighted)",
    "LGD_Weighted": "LGD (NBV-weighted)",
    "NBV_CAGR": "NBV CAGR",
    "Growth_Consistency": "Growth consistency",
    "Engagement_Decay": "Engagement retention",
    "Term_Avg": "Average term (months)",
}


def growth_consistency(y1: np.ndarray, y2: np.ndarray, y3: np.ndarray) -> np.ndarray:
    """1.0 = both year-pairs growing, 0.5 = mixed / unknown, 0.0 = both declining."""
    y2 = np.nan_to_num(y2, nan=0.0)
    y3 = np.nan_to_num(y3, nan=0.0)
    has_y2, has_y3 = y2 > 0, y3 > 0
    y1_gt_y2 = (y1 > y2) & has_y2
    y2_gt_y3 = (y2 > y3) & has_y3
    gc = np.full(len(y1), 0.5, dtype=np.float64)
    gc[y1_gt_y2 & y2_gt_y3] = 1.0
    gc[(~y1_gt_y2 & has_y2) & (~y2_gt_y3 & has_y3)] = 0.0
    return gc


def missing_columns(columns: Iterable[str]) -> list[str]:
    cols = set(columns)
    return [c for c in REQUIRED_COLUMNS if c not in cols]


def prepare_gold(df: pd.DataFrame) -> pd.DataFrame:
    df = df.copy()
    if "Market" not in df.columns:
        df["Market"] = df["ConsolidationCountryCode"].astype(str) + "_" + df["Business_Unit_Code"].astype(str)
    for c in ("Party_Name", "Dealer_Segment"):
        if c not in df.columns:
            df[c] = None
    nbv_safe = df["NBV_EUR"].replace(0, np.nan)
    if "PD_Weighted" not in df.columns:
        df["PD_Weighted"] = df["PD_Weighted_Sum"] / nbv_safe
    if "LGD_Weighted" not in df.columns:
        df["LGD_Weighted"] = df["LGD_Weighted_Sum"] / nbv_safe
    df["Growth_Consistency"] = growth_consistency(
        df["NBV_EUR"].to_numpy(dtype=float),
        df["Y2_NBV"].to_numpy(dtype=float),
        df["Y3_NBV"].to_numpy(dtype=float),
    )
    num = df.select_dtypes(include=[np.number]).columns
    df[num] = df[num].replace([np.inf, -np.inf], np.nan)
    df["SellingParty_ID"] = df["SellingParty_ID"].astype("int64")
    return df


def _eff_log(metric: float, nbv: float) -> float:
    metric = max(float(metric or 0.0), 0.0)
    if not nbv:
        return np.nan
    return (metric / nbv) * np.log1p(metric)


def engineer_features(raw: Dict[str, float], cagr_cap: float) -> Dict[str, float]:
    """Gold feature formulas for a single dealer (raw values are Y1 yearly sums)."""
    nbv = float(raw.get("NBV_EUR") or 0.0)
    contracts = float(raw.get("Distinct_Contracts") or 0.0)
    y2 = float(raw.get("Y2_NBV") or 0.0)
    y3 = float(raw.get("Y3_NBV") or 0.0)

    if y3 > 0:
        cagr = (nbv / y3) ** 0.5 - 1
    elif y2 > 0:
        cagr = nbv / y2 - 1
    else:
        cagr = cagr_cap
    cagr = float(np.clip(cagr, -0.99, cagr_cap))

    peak = raw.get("Peak_Exposure")
    current = raw.get("Current_Exposure") or 0.0
    engagement = float(np.clip(current / peak, 0, 1)) if peak and peak > 0 else 1.0

    out = {
        "GP_Eff_log": _eff_log(raw.get("Gross_Profit"), nbv),
        "RAM_eff_log": _eff_log(raw.get("Risk_Adjusted_Margin"), nbv),
        "Fee_Eff_log": _eff_log(raw.get("Upfront_Fees"), nbv),
        "UpfrontFees_Eff_log": _eff_log(raw.get("Upfront_Fees"), nbv),
        "Residual_Exp_log": _eff_log(raw.get("Booked_Residual_Total"), nbv),
        "FMV_Eff_log": _eff_log(raw.get("FMV_NBV"), nbv),
        "DealerDirect_Eff_log": _eff_log(raw.get("DealerDirect_NBV"), nbv),
        "Insurance_Eff_log": _eff_log(raw.get("Insurance_Income"), nbv),
        "Expected_Loss": ((raw.get("PD_Weighted_Sum") or 0) / nbv) * ((raw.get("LGD_Weighted_Sum") or 0) / nbv) if nbv else np.nan,
        "log_NBV": float(np.log1p(nbv)),
        "log_Contracts": float(np.log1p(contracts)),
        "NBV_CAGR": cagr,
        "Engagement_Decay": engagement,
        "Term_Avg": (raw.get("Term_Weighted") or 0) / nbv if nbv else 0.0,
        "Avg_Deal_Size": nbv / contracts if contracts > 0 else 0.0,
        "PD_Weighted": (raw.get("PD_Weighted_Sum") or 0) / nbv if nbv else np.nan,
        "LGD_Weighted": (raw.get("LGD_Weighted_Sum") or 0) / nbv if nbv else np.nan,
        "Growth_Consistency": float(growth_consistency(np.array([nbv]), np.array([y2]), np.array([y3]))[0]),
    }
    return out


def raw_from_rates(inputs: Dict[str, float]) -> Dict[str, float]:
    """Convert the user-friendly 'score a dealer' form into silver-level sums.

    The form asks for PD / LGD as rates and the average term in months; the
    pipeline stores them as NBV-weighted sums.
    """
    optional = {"Y2_NBV", "Y3_NBV", "Current_Exposure", "Peak_Exposure"}
    raw = {}
    for k in RAW_COLUMNS:
        v = inputs.get(k)
        raw[k] = (None if k in optional else 0.0) if v is None or v == "" else float(v)
    nbv = float(inputs.get("NBV_EUR") or 0.0)
    if "PD_Rate" in inputs:
        raw["PD_Weighted_Sum"] = float(inputs["PD_Rate"] or 0) * nbv
    if "LGD_Rate" in inputs:
        raw["LGD_Weighted_Sum"] = float(inputs["LGD_Rate"] or 0) * nbv
    if "Term_Avg" in inputs:
        raw["Term_Weighted"] = float(inputs["Term_Avg"] or 0) * nbv
    if not inputs.get("Active_Periods"):
        raw["Active_Periods"] = 12.0
    return raw
