"""Saved GMM model files (.pkl) from the pipeline — loaded for prediction only.

Nothing is fitted here. The reader accepts several layouts because the
pipeline's pickle format is not fixed:
  * one file per market (market code in the file name, e.g. ..._US_OE_....pkl)
  * one file for all markets: a dict keyed by market code, or {"markets": {...}}
Inside a market's entry it looks for a fitted GaussianMixture (has
predict_proba), a fitted scaler (has transform), the feature list, the feature
weight vector and, optionally, cluster → archetype names.
"""
from __future__ import annotations

import logging
import pickle
import re
import threading
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Dict, List, Optional

import numpy as np

from .. import settings

log = logging.getLogger(__name__)
MARKET_RE = re.compile(r"(?<![A-Z])([A-Z]{2}_[A-Z]{2,3})(?![A-Z])")
TS_RE = re.compile(r"(\d{8}_\d{6})")


@dataclass
class ModelBundle:
    file: str
    market: str
    gmm: Any = None
    scaler: Any = None
    features: List[str] = field(default_factory=list)
    weight_vector: Optional[np.ndarray] = None
    archetype_names: Dict[int, str] = field(default_factory=dict)
    version: Optional[str] = None
    error: Optional[str] = None

    @property
    def ok(self) -> bool:
        return self.error is None and self.gmm is not None and self.scaler is not None


_lock = threading.Lock()
_cache: Dict[str, Any] = {}


def files() -> List[Path]:
    return sorted(settings.MODEL_DIR.rglob("*.pkl")) if settings.MODEL_DIR.exists() else []


def signature() -> tuple:
    return tuple((str(p), p.stat().st_mtime) for p in files())


def _load(p: Path) -> Any:
    key = f"{p}:{p.stat().st_mtime}"
    with _lock:
        if key in _cache:
            return _cache[key]
    with open(p, "rb") as fh:
        obj = pickle.load(fh)  # trusted: only files placed in the app's own MODEL_DIR
    with _lock:
        _cache[key] = obj
    return obj


def _walk(obj: Any, depth: int = 0):
    yield obj
    if depth < 3 and isinstance(obj, dict):
        for v in obj.values():
            yield from _walk(v, depth + 1)


def _find_key(obj: Any, names: List[str]) -> Any:
    for o in _walk(obj):
        if isinstance(o, dict):
            for n in names:
                if n in o and o[n] is not None:
                    return o[n]
    return None


def _market_entry(obj: Any, market: str) -> Optional[Any]:
    if isinstance(obj, dict):
        if market in obj:
            return obj[market]
        for k in ("markets", "models", "market_models"):
            if isinstance(obj.get(k), dict) and market in obj[k]:
                return obj[k][market]
    return None


def bundle_for(market: str, default_features: List[str], default_weights: Dict[str, float]) -> Optional[ModelBundle]:
    candidates = []
    for p in files():
        m = MARKET_RE.search(p.name)
        if m is None or m.group(1) == market:
            ts = TS_RE.search(p.name)
            candidates.append((m is not None, ts.group(1) if ts else "", p.stat().st_mtime, p))
    if not candidates:
        return None
    # Prefer a market-specific file, then the newest.
    _, _, _, path = max(candidates)
    rel = str(path.relative_to(settings.MODEL_DIR)).replace("\\", "/")
    try:
        obj = _load(path)
    except Exception as e:
        return ModelBundle(file=rel, market=market, error=f"Could not read the file: {type(e).__name__}: {str(e)[:200]}")
    entry = _market_entry(obj, market)
    if entry is None and MARKET_RE.search(path.name) is None:
        return ModelBundle(file=rel, market=market, error=f"No entry for {market} in this model file.")
    entry = obj if entry is None else entry

    gmm = next((o for o in _walk(entry) if hasattr(o, "predict_proba") and hasattr(o, "means_")), None)
    scaler = next((o for o in _walk(entry) if hasattr(o, "transform") and (hasattr(o, "mean_") or hasattr(o, "scale_"))
                   and not hasattr(o, "predict_proba")), None)
    b = ModelBundle(file=rel, market=market, gmm=gmm, scaler=scaler)
    if gmm is None or scaler is None:
        b.error = "The file has no fitted GMM and scaler for this market."
        return b

    feats = _find_key(entry, ["features", "feature_list", "clustering_features"])
    if not (isinstance(feats, (list, tuple)) and all(isinstance(f, str) for f in feats)):
        feats = list(getattr(scaler, "feature_names_in_", [])) or default_features
    b.features = list(feats)
    n = getattr(gmm, "n_features_in_", len(b.features))
    if n != len(b.features):
        b.error = f"Model expects {n} features but {len(b.features)} are known."
        return b

    wv = _find_key(entry, ["weight_vector", "wv"])
    if wv is not None and len(np.ravel(wv)) == n:
        b.weight_vector = np.asarray(wv, dtype=float).ravel()
    else:
        w = _find_key(entry, ["weights", "effective_weights"])
        w = w if isinstance(w, dict) and all(f in w for f in b.features) else default_weights
        total = sum(float(w[f]) for f in b.features) or 1.0
        b.weight_vector = np.array([float(w[f]) / total for f in b.features])

    names = _find_key(entry, ["archetype_names", "arch_names", "cluster_names"])
    if isinstance(names, dict):
        b.archetype_names = {int(k): str(v) for k, v in names.items()}
    ver = _find_key(entry, ["version_id", "version", "model_version"])
    b.version = str(ver) if ver is not None else None
    return b
