"""On-demand segment prediction for one dealer, with an AI explanation.

Uses what already exists — nothing is trained or re-fitted:
  * market context from the gold features, computed exactly as the pipeline
    does (market-median imputation, dimension scores as ratios to the market
    median, P30/P70 Weak/Strong thresholds, P30/median/P70 benchmarks);
  * the saved GMM + scaler (if uploaded) to place the dealer in a cluster /
    archetype — prediction only;
  * the model's LLM prompt to assign the segment and explain it. If the AI
    service is unavailable, the model's rule-based fallback assigns the
    segment and the explanation is generated from the scores.
"""
from __future__ import annotations

import logging
import threading
from typing import Dict, List, Optional

import numpy as np
import pandas as pd

from .. import dataset, settings
from . import ai, model_store
from .features import engineer_features, raw_from_rates
from .scoring import (
    RAW_PROFILE_FEATURES, benchmark_lookup, benchmark_row, compute_dimension_thresholds, compute_market_benchmarks,
    dealer_dimension_scores, dimension_reference, dims_dict, fallback_segment, fmt_by, format_benchmark_table_text,
    metric_key, raw_equivalents, raw_frame,
)

log = logging.getLogger(__name__)
DEFAULT_TH = (0.95, 1.05)


class NotSupported(ValueError):
    pass


def _market_weights(cfg: dict, market: str) -> Dict[str, float]:
    w = dict(cfg["default_weights"])
    w.update(cfg.get("market_weights", {}).get(market, {}))
    return {f: float(w.get(f, 0)) for f in cfg["features"]}


def name_archetype(ds: Dict[str, float], th: Dict[str, tuple]) -> str:
    def strong(d): return ds.get(d, 1.0) > th.get(d, DEFAULT_TH)[1]
    def weak(d): return ds.get(d, 1.0) < th.get(d, DEFAULT_TH)[0]
    if strong("Risk Adjusted Margin") and strong("Volume") and strong("Risk"):
        return "Premium / Balanced"
    if strong("Risk Adjusted Margin") and not weak("Risk") and not weak("Volume"):
        return "Profit Champion"
    if strong("Volume") and not weak("Risk Adjusted Margin") and not weak("Risk") and not strong("Risk Adjusted Margin"):
        return "Volume Champion"
    if strong("Growth") or (strong("Relationship Depth") and not strong("Risk Adjusted Margin") and not weak("Risk")):
        return "Growth / Emerging"
    if (weak("Risk Adjusted Margin") or weak("Risk")) and weak("Volume"):
        return "Challenged / High-Risk"
    if (weak("Risk Adjusted Margin") or weak("Risk")) and not weak("Volume"):
        return "Watch List"
    return "Standard / Moderate"


class MarketContext:
    def __init__(self, market: str, gold_raw: pd.DataFrame):
        cfg = settings.model_config()
        self.market = market
        self.cfg = cfg
        self.dims = cfg["dimension_order"]
        self.feats = [f for f in cfg["features"] if f in gold_raw.columns]
        self.weights = _market_weights(cfg, market)
        df = gold_raw[gold_raw["Market"] == market].copy()
        for c in self.feats:  # market-median imputation, as in the pipeline
            if df[c].isna().any():
                df.loc[df[c].isna(), c] = df[c].median()
        self.df = df.dropna(subset=self.feats)
        self.index = {str(i): ix for ix, i in zip(self.df.index, self.df["SellingParty_ID"])}
        vals = raw_equivalents(self.df, self.feats)
        self.ds = dealer_dimension_scores(vals, self.feats, self.weights, cfg["feature_dimensions"], cfg["ratio_clamp"])
        self.th = compute_dimension_thresholds(self.ds, cfg["threshold_quantiles"])
        self.reference = dimension_reference(vals)
        self.raw = raw_frame(self.df)
        self.bench = compute_market_benchmarks(self.raw, cfg["benchmark_quantiles"], cfg["outlier_iqr_multiplier"])
        self.prompt = ai.system_prompt(cfg, market, format_benchmark_table_text(self.bench, cfg["benchmark_quantiles"]))
        self.ranges = {f: (float(self.df[f].min()), float(self.df[f].max())) for f in self.feats}
        self.cagr_cap = float(self.df["NBV_CAGR"].max())

        self.model = model_store.bundle_for(market, self.feats, self.weights)
        self.labels: Optional[np.ndarray] = None
        self.probs: Optional[np.ndarray] = None
        self.arch_names: Dict[int, str] = {}
        if self.model and self.model.ok:
            try:
                self.probs = self._cluster_probs(self.df)
                self.labels = self.probs.argmax(axis=1)
                self.arch_names = dict(self.model.archetype_names)
                for c in np.unique(self.labels):
                    if int(c) not in self.arch_names:
                        med = {d: float(self.ds.loc[self.labels == c, d].median()) for d in self.dims if d in self.ds}
                        self.arch_names[int(c)] = name_archetype(med, self.th)
            except Exception as e:
                self.model.error = f"The saved model could not be applied: {e}"
                self.labels = self.probs = None

    def _cluster_probs(self, frame: pd.DataFrame) -> np.ndarray:
        m = self.model
        X = frame.reindex(columns=m.features).astype(float).to_numpy()
        X = np.nan_to_num(X, nan=0.0)
        Xw = m.scaler.transform(X) * m.weight_vector[np.newaxis, :]
        return m.gmm.predict_proba(Xw)

    def model_status(self) -> dict:
        if self.model is None:
            return {"available": False, "message": "No saved model uploaded — cluster and archetype are not shown."}
        if not self.model.ok:
            return {"available": False, "file": self.model.file, "message": self.model.error}
        return {"available": True, "file": self.model.file, "version": self.model.version,
                "clusters": int(getattr(self.model.gmm, "n_components", 0))}


_lock = threading.Lock()
_contexts: Dict[str, tuple] = {}
_results: Dict[tuple, dict] = {}


def context(market: str) -> MarketContext:
    cfg = settings.model_config()
    if market not in cfg["markets"]:
        raise NotSupported(f"{market} is not one of the markets the model covers ({', '.join(cfg['markets'])}).")
    ds = dataset.get()
    if ds.gold_raw is None:
        raise NotSupported("Gold dealer features are not available.")
    n = int((ds.gold_raw["Market"] == market).sum())
    if n < int(cfg["min_dealers"]):
        raise NotSupported(f"{market} has {n} dealers; the model needs at least {cfg['min_dealers']}.")
    key = (ds.loaded_at, model_store.signature())
    with _lock:
        hit = _contexts.get(market)
        if hit and hit[0] == key:
            return hit[1]
    ctx = MarketContext(market, ds.gold_raw)
    with _lock:
        _contexts[market] = (key, ctx)
    return ctx


FRIENDLY = {
    "NBV (EUR)": "New business volume", "Risk Adjusted Margin (EUR)": "Risk-adjusted margin",
    "RAM / NBV": "Margin % of volume", "PD": "Probability of default", "LGD": "Loss given default",
    "Expected loss rate": "Expected loss rate", "Distinct contracts": "Number of contracts",
    "Active periods": "Active months", "NBV growth (CAGR)": "Volume growth", "Growth consistency": "Growth consistency",
    "Engagement retention": "Portfolio retention", "FMV NBV (EUR)": "FMV volume",
    "Dealer-direct NBV (EUR)": "Dealer-direct volume", "Booked residual (EUR)": "Booked residual value",
}


def _metrics(raw_row: pd.Series, bench: List[dict]) -> List[dict]:
    out = []
    for name, _src, kind, favour in RAW_PROFILE_FEATURES:
        v = raw_row.get(name)
        v = None if v is None or pd.isna(v) else float(v)
        b = benchmark_row(bench, name)
        lk = benchmark_lookup(v, b)
        out.append({"key": name, "name": FRIENDLY.get(name, name), "value": v, "display": fmt_by(v, kind), "favour": favour,
                    "p30": b.get("p_lo") if b else None, "median": b.get("p50") if b else None,
                    "p70": b.get("p_hi") if b else None, "verdict": lk["verdict"],
                    "outlier": lk["outlier_direction"] if lk["is_outlier"] else None})
    return out


def _explain_rules(segment: str, d: Dict[str, float], th: dict, metrics: List[dict]) -> str:
    strong = [k for k, v in d.items() if v > th.get(k, DEFAULT_TH)[1]]
    weak = [k for k, v in d.items() if v < th.get(k, DEFAULT_TH)[0]]
    good = [m["name"] for m in metrics if m["verdict"] == "good"][:3]
    poor = [m["name"] for m in metrics if m["verdict"] == "poor"][:3]
    parts = [f"{segment} based on the model's scoring rules."]
    if strong:
        parts.append(f"Strong on {', '.join(strong)}.")
    if weak:
        parts.append(f"Weak on {', '.join(weak)}.")
    if good:
        parts.append(f"Better than most of the market on {', '.join(good)}.")
    if poor:
        parts.append(f"Behind most of the market on {', '.join(poor)}.")
    return " ".join(parts)


def _decide(ctx: MarketContext, dealer_id: str, ds_row: pd.Series, raw_row: pd.Series,
            cluster: Optional[int], cluster_conf: Optional[float]) -> dict:
    d = dims_dict(ds_row, ctx.dims)
    metrics = _metrics(raw_row, ctx.bench)
    payload_metrics = {}
    for m in metrics:
        entry = {"value": m["display"]}
        if m["median"]:
            entry["median"] = m["median"]
        if m["verdict"] != "context":
            entry["verdict"] = m["verdict"]
        if m["outlier"]:
            entry["outlier"] = m["outlier"]
        payload_metrics[metric_key(m["key"])] = entry
    payload = {"dealer_id": int(dealer_id) if str(dealer_id).isdigit() else 0, "market": ctx.market,
               "dimension_scores": {k: round(v, 2) for k, v in d.items()}}
    if cluster_conf is not None:
        payload["cluster_confidence"] = round(cluster_conf, 2)
    payload["raw_metrics"] = payload_metrics

    answer, status = ai.assign(ctx.prompt, payload)
    if answer:
        segment, confidence, rationale, source = answer["segment"], answer["confidence"], answer["rationale"], "ai"
    else:
        segment = fallback_segment(d, ctx.th, ctx.dims)
        confidence, rationale, source = None, _explain_rules(segment, d, ctx.th, metrics), "rules"

    return {
        "market": ctx.market, "segment": segment, "confidence": confidence, "explanation": rationale,
        "source": source, "ai_status": status,
        "archetype": ctx.arch_names.get(cluster) if cluster is not None else None,
        "cluster": cluster, "cluster_confidence": cluster_conf,
        "dimensions": [{"dimension": k, "score": d.get(k), "band": list(ctx.th.get(k, DEFAULT_TH)),
                        "level": ("Strong" if d.get(k, 1) > ctx.th.get(k, DEFAULT_TH)[1] else
                                  "Weak" if d.get(k, 1) < ctx.th.get(k, DEFAULT_TH)[0] else "Average")}
                       for k in ctx.dims if k in d],
        "metrics": metrics,
        "model": ctx.model_status(),
        "endpoint": settings.model_config()["llm"]["endpoint"],
    }


def predict_existing(market: str, dealer_id: str, refresh: bool = False) -> dict:
    ctx = context(market)
    ix = ctx.index.get(str(dealer_id))
    if ix is None:
        raise KeyError(f"Dealer {dealer_id} not found in {market}")
    key = (market, str(dealer_id), id(ctx))
    with _lock:
        if not refresh and key in _results:
            return _results[key]
    pos = ctx.df.index.get_loc(ix)
    cluster = int(ctx.labels[pos]) if ctx.labels is not None else None
    conf = float(ctx.probs[pos].max()) if ctx.probs is not None else None
    res = _decide(ctx, str(dealer_id), ctx.ds.loc[ix], ctx.raw.loc[ix], cluster, conf)
    if res["source"] == "ai":
        with _lock:
            _results[key] = res
    return res


INPUT_FIELDS = [
    {"key": "NBV_EUR", "label": "New business volume, last 12 months (EUR)", "kind": "eur", "required": True},
    {"key": "Y2_NBV", "label": "New business volume, 12–24 months ago (EUR)", "kind": "eur"},
    {"key": "Y3_NBV", "label": "New business volume, 24–36 months ago (EUR)", "kind": "eur"},
    {"key": "Risk_Adjusted_Margin", "label": "Risk-adjusted margin (EUR)", "kind": "eur", "required": True},
    {"key": "Gross_Profit", "label": "Gross profit (EUR)", "kind": "eur", "required": True},
    {"key": "Upfront_Fees", "label": "Upfront / documentation fees (EUR)", "kind": "eur"},
    {"key": "Insurance_Income", "label": "Insurance income (EUR)", "kind": "eur"},
    {"key": "Booked_Residual_Total", "label": "Booked residual value (EUR)", "kind": "eur"},
    {"key": "FMV_NBV", "label": "FMV / FPPO volume (EUR)", "kind": "eur"},
    {"key": "DealerDirect_NBV", "label": "Dealer-direct volume (EUR)", "kind": "eur"},
    {"key": "PD_Rate", "label": "Probability of default (0.012 = 1.2%)", "kind": "rate", "required": True},
    {"key": "LGD_Rate", "label": "Loss given default (0.35 = 35%)", "kind": "rate", "required": True},
    {"key": "Term_Avg", "label": "Average deal term (months)", "kind": "num"},
    {"key": "Distinct_Contracts", "label": "Number of contracts", "kind": "int", "required": True},
    {"key": "Active_Periods", "label": "Active months (of last 12)", "kind": "int"},
    {"key": "Current_Exposure", "label": "Current exposure, avg of last 3 months (EUR)", "kind": "eur"},
    {"key": "Peak_Exposure", "label": "Peak monthly exposure (EUR)", "kind": "eur"},
]


def form_defaults(market: str) -> Dict[str, float]:
    ctx = context(market)
    df = ctx.df
    nbv = df["NBV_EUR"].replace(0, np.nan)
    out = {k: float(df[k].median()) for k in ("NBV_EUR", "Y2_NBV", "Y3_NBV", "Risk_Adjusted_Margin", "Gross_Profit",
                                              "Upfront_Fees", "Insurance_Income", "Booked_Residual_Total", "FMV_NBV",
                                              "DealerDirect_NBV", "Term_Avg", "Distinct_Contracts", "Active_Periods",
                                              "Current_Exposure", "Peak_Exposure") if k in df}
    out["PD_Rate"] = float((df["PD_Weighted_Sum"] / nbv).median())
    out["LGD_Rate"] = float((df["LGD_Weighted_Sum"] / nbv).median())
    return {k: (round(v, 4) if abs(v) < 10 else round(v)) for k, v in out.items() if np.isfinite(v)}


def predict_new(market: str, inputs: Dict[str, float]) -> dict:
    ctx = context(market)
    if not inputs.get("NBV_EUR") or float(inputs["NBV_EUR"]) <= 0:
        raise ValueError("New business volume must be greater than zero.")
    raw = raw_from_rates(inputs)
    feats = engineer_features(raw, ctx.cagr_cap)
    clipped = []
    for f, (lo, hi) in ctx.ranges.items():
        v = feats.get(f)
        if v is not None and np.isfinite(v):
            c = float(np.clip(v, lo, hi))
            if c != v:
                clipped.append(f)
            feats[f] = c
    row = pd.DataFrame([{**raw, **feats, "SellingParty_ID": 0, "Market": market}])
    vals = raw_equivalents(row, ctx.feats)
    ds = dealer_dimension_scores(vals, ctx.feats, ctx.weights, ctx.cfg["feature_dimensions"], ctx.cfg["ratio_clamp"],
                                 reference=ctx.reference)
    cluster = conf = None
    if ctx.labels is not None:
        p = ctx._cluster_probs(row)[0]
        cluster, conf = int(p.argmax()), float(p.max())
    res = _decide(ctx, "0", ds.iloc[0], raw_frame(row).iloc[0], cluster, conf)
    res["clipped_features"] = clipped
    return res
