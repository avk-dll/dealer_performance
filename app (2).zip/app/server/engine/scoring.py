"""Scoring primitives shared by every pipeline method.

Behaviour matches the original analysis except where marked FIX; those
corrections are listed in the project README.
"""
from __future__ import annotations

import re
from typing import Callable, Dict, List, Optional, Sequence, Tuple

import numpy as np
import pandas as pd

SEGMENT_ORDER = ["Cherish", "Grow", "Maintain", "Monitor"]
SEGMENT_RANK = {s: i for i, s in enumerate(SEGMENT_ORDER)}
DEFAULT_THRESHOLD = (0.95, 1.05)


def _per_nbv(col: str) -> Callable[[pd.DataFrame], pd.Series]:
    return lambda d: d[col] / d["NBV_EUR"].replace(0, np.nan)


def _expected_loss_rate(d: pd.DataFrame) -> pd.Series:
    return _per_nbv("PD_Weighted_Sum")(d) * _per_nbv("LGD_Weighted_Sum")(d)


# (display_name, source, format_kind, favour_direction)
RAW_PROFILE_FEATURES: List[Tuple[str, object, str, str]] = [
    ("NBV (EUR)", "NBV_EUR", "eur", "higher"),
    ("Risk Adjusted Margin (EUR)", "Risk_Adjusted_Margin", "eur", "higher"),
    ("RAM / NBV", _per_nbv("Risk_Adjusted_Margin"), "pct", "higher"),
    ("PD", _per_nbv("PD_Weighted_Sum"), "pct", "lower"),
    ("LGD", _per_nbv("LGD_Weighted_Sum"), "pct", "lower"),
    ("Expected loss rate", _expected_loss_rate, "pct", "lower"),
    ("Distinct contracts", "Distinct_Contracts", "int", "higher"),
    ("Active periods", "Active_Periods", "int", "higher"),
    ("NBV growth (CAGR)", "NBV_CAGR", "pct", "higher"),
    ("Growth consistency", "Growth_Consistency", "num", "higher"),
    ("Engagement retention", "Engagement_Decay", "pct", "higher"),
    ("FMV NBV (EUR)", "FMV_NBV", "eur", "higher"),
    ("Dealer-direct NBV (EUR)", "DealerDirect_NBV", "eur", "higher"),
    ("Booked residual (EUR)", "Booked_Residual_Total", "eur", "higher"),
]

# Engineered feature -> raw business equivalent used for dimension scoring.
RAW_EQUIVALENTS: Dict[str, object] = {
    "RAM_eff_log": _per_nbv("Risk_Adjusted_Margin"),
    "GP_Eff_log": _per_nbv("Gross_Profit"),
    "Fee_Eff_log": lambda d: (d["Upfront_Fees"] + d["Insurance_Income"]) / d["NBV_EUR"].replace(0, np.nan),
    "Insurance_Eff_log": _per_nbv("Insurance_Income"),
    "Residual_Exp_log": "Booked_Residual_Total",
    "FMV_Eff_log": _per_nbv("FMV_NBV"),
    "DealerDirect_Eff_log": _per_nbv("DealerDirect_NBV"),
    "log_NBV": "NBV_EUR",
    "log_Contracts": "Distinct_Contracts",
    "Avg_Deal_Size": "Avg_Deal_Size",
    "PD_Weighted": _per_nbv("PD_Weighted_Sum"),
    "LGD_Weighted": _per_nbv("LGD_Weighted_Sum"),
    "NBV_CAGR": "NBV_CAGR",
    "Growth_Consistency": "Growth_Consistency",
    "Engagement_Decay": "Engagement_Decay",
    "Term_Avg": "Term_Avg",
}


# ── Formatting ───────────────────────────────────────────────────────────────

def fmt_eur(v) -> str:
    if v is None or pd.isna(v):
        return "n/a"
    if abs(v) >= 1e6:
        return f"€{v / 1e6:,.1f}M"
    if abs(v) >= 1e3:
        return f"€{v / 1e3:,.0f}K"
    return f"€{v:,.0f}"


def fmt_pct(v) -> str:
    # FIX: the original code printed values >= 1 without scaling, so a 215% CAGR
    # reached the LLM as "2.15%". Rates are always fractions here.
    if v is None or pd.isna(v):
        return "n/a"
    return f"{v * 100:.2f}%"


def fmt_by(v, kind: str) -> str:
    if v is None or pd.isna(v):
        return "n/a"
    if kind == "eur":
        return fmt_eur(v)
    if kind == "pct":
        return fmt_pct(v)
    if kind == "int":
        return f"{int(v):,}"
    return f"{v:.2f}"


def metric_key(name: str) -> str:
    # FIX: the original code produced keys like "ram__per__nbv"; the few-shot
    # examples use "ram_per_nbv".
    s = name.lower().replace("/", " per ")
    return re.sub(r"[^a-z0-9]+", "_", s).strip("_")


# ── Benchmarks ───────────────────────────────────────────────────────────────

def raw_frame(df: pd.DataFrame) -> pd.DataFrame:
    out = pd.DataFrame(index=df.index)
    for name, src, _kind, _fav in RAW_PROFILE_FEATURES:
        if callable(src):
            out[name] = src(df)
        else:
            out[name] = df[src] if src in df.columns else np.nan
    return out.replace([np.inf, -np.inf], np.nan)


def compute_market_benchmarks(raw: pd.DataFrame, quantiles: Sequence[float], iqr_mult: float) -> List[dict]:
    bench = []
    for name, _src, kind, favour in RAW_PROFILE_FEATURES:
        s = raw[name].dropna()
        if len(s) < 5:
            bench.append({"feature": name, "favour": favour, "kind": kind})
            continue
        p_lo, p50, p_hi = float(s.quantile(quantiles[0])), float(s.median()), float(s.quantile(quantiles[1]))
        q1, q3 = float(s.quantile(0.25)), float(s.quantile(0.75))
        iqr = q3 - q1
        ol, oh = q1 - iqr_mult * iqr, q3 + iqr_mult * iqr
        bench.append({
            "feature": name, "favour": favour, "kind": kind,
            "p_lo": fmt_by(p_lo, kind), "p50": fmt_by(p50, kind), "p_hi": fmt_by(p_hi, kind),
            "p_lo_num": p_lo, "median_num": p50, "p_hi_num": p_hi,
            "good": fmt_by(p_hi if favour == "higher" else p_lo, kind),
            "poor": fmt_by(p_lo if favour == "higher" else p_hi, kind),
            "outlier_low": ol, "outlier_high": oh,
            "n_low_outliers": int((s < ol).sum()), "n_high_outliers": int((s > oh).sum()),
        })
    return bench


def benchmark_row(bench: List[dict], name: str) -> Optional[dict]:
    return next((b for b in bench if b["feature"] == name), None)


def benchmark_lookup(value, b_row: Optional[dict]) -> dict:
    if b_row is None or value is None or pd.isna(value) or "p_lo_num" not in b_row:
        return {"verdict": "context", "is_outlier": False, "outlier_direction": None}
    is_outlier = value < b_row["outlier_low"] or value > b_row["outlier_high"]
    direction = "low" if value < b_row["outlier_low"] else ("high" if value > b_row["outlier_high"] else None)
    if b_row.get("favour") == "higher":
        verdict = "good" if value >= b_row["p_hi_num"] else ("poor" if value <= b_row["p_lo_num"] else "average")
    else:
        verdict = "good" if value <= b_row["p_lo_num"] else ("poor" if value >= b_row["p_hi_num"] else "average")
    return {"verdict": verdict, "is_outlier": bool(is_outlier), "outlier_direction": direction}


def format_benchmark_table_text(bench: List[dict], quantiles: Sequence[float]) -> str:
    lo, hi = f"P{int(quantiles[0] * 100)}", f"P{int(quantiles[1] * 100)}"
    lines = [f"{'Feature':<30} {lo:>12} {'Median':>12} {hi:>12} {'Good':>12} {'Poor':>12}", "-" * 90]
    for b in bench:
        if "p50" not in b:
            continue
        lines.append(f"{b['feature']:<30} {b['p_lo']:>12} {b['p50']:>12} {b['p_hi']:>12} {b['good']:>12} {b['poor']:>12}")
    return "\n".join(lines)


# ── Dimension scoring ────────────────────────────────────────────────────────

def raw_equivalents(df: pd.DataFrame, feats: Sequence[str]) -> pd.DataFrame:
    vals = pd.DataFrame(index=df.index)
    for f in feats:
        src = RAW_EQUIVALENTS.get(f, f)
        if callable(src):
            vals[f] = src(df)
        else:
            vals[f] = df[src] if isinstance(src, str) and src in df.columns else np.nan
    return vals.replace([np.inf, -np.inf], np.nan)


def dimension_reference(vals: pd.DataFrame) -> dict:
    """What a saved version needs to score a single new dealer the same way."""
    return {
        "medians": {f: _num(vals[f].median()) for f in vals.columns},
        "values": {f: sorted(float(x) for x in vals[f].dropna().tolist()) for f in vals.columns},
    }


def _num(v):
    return None if v is None or pd.isna(v) else float(v)


def _rank_pct_against(values: pd.Series, reference: List[float]) -> pd.Series:
    ref = np.asarray(reference, dtype=float)
    if ref.size == 0:
        return pd.Series(np.nan, index=values.index)
    x = values.to_numpy(dtype=float)
    lo = np.searchsorted(ref, x, side="left")
    hi = np.searchsorted(ref, x, side="right")
    # Average-rank percentile of x as if it were added to the reference set.
    pct = (lo + (hi - lo) / 2.0 + 0.5) / (ref.size + 1)
    pct = np.where(np.isnan(x), np.nan, pct)
    return pd.Series(np.clip(pct, 0, 1), index=values.index)


def dealer_dimension_scores(
    vals: pd.DataFrame,
    feats: Sequence[str],
    weights: Dict[str, float],
    feature_dims: Dict[str, dict],
    ratio_clamp: Sequence[float],
    reference: Optional[dict] = None,
) -> pd.DataFrame:
    """Per-dealer dimension scores: weighted ratios to the market median.

    1.0 = market median; higher is always better (risk features inverted).
    `reference` is used when scoring dealers outside the fitted market.
    """
    medians = reference["medians"] if reference else {f: _num(vals[f].median()) for f in feats}
    parts: Dict[str, list] = {}
    for f in feats:
        info = feature_dims.get(f)
        if info is None or f not in vals.columns:
            continue
        om = medians.get(f)
        if om is not None and np.isfinite(om) and om > 0:
            r = np.clip(vals[f] / om, ratio_clamp[0], ratio_clamp[1])
        elif reference:
            r = _rank_pct_against(vals[f], reference["values"].get(f, [])) / 0.5
        else:
            r = vals[f].rank(pct=True) / 0.5
        if info["direction"] == -1:
            r = 2.0 - r
        parts.setdefault(info["dimension"], []).append((r, abs(float(weights.get(f, 0)))))
    result = {}
    for dim, lst in parts.items():
        total = sum(w for _, w in lst)
        if total > 0:
            result[dim] = sum(r * w for r, w in lst) / total
    return pd.DataFrame(result, index=vals.index)


def compute_dimension_thresholds(ds: pd.DataFrame, quantiles: Sequence[float]) -> Dict[str, Tuple[float, float]]:
    th = {}
    for d in ds.columns:
        s = ds[d].dropna()
        if len(s) < 10:
            th[d] = DEFAULT_THRESHOLD
            continue
        lo, hi = float(s.quantile(quantiles[0])), float(s.quantile(quantiles[1]))
        c = float(s.median())
        th[d] = (min(lo, c - 0.05), max(hi, c + 0.05))
    return th


def _strong(ds: dict, th: dict, d: str) -> bool:
    return ds.get(d, 1.0) > th.get(d, DEFAULT_THRESHOLD)[1]


def _weak(ds: dict, th: dict, d: str) -> bool:
    return ds.get(d, 1.0) < th.get(d, DEFAULT_THRESHOLD)[0]


def stat_composite(ds: dict, dims: Sequence[str]) -> float:
    """Deterministic 0-100 composite from dimension scores (the statistical anchor).

    Risk Adjusted Margin and Risk weighted highest: 25% each, the
    remaining dimensions share 50%.
    """
    others = [d for d in dims if d not in ("Risk Adjusted Margin", "Risk")]
    total = 0.0
    for d in dims:
        w = 0.25 if d in ("Risk Adjusted Margin", "Risk") else (0.5 / len(others) if others else 0.0)
        total += ds.get(d, 1.0) * w
    return float(min(max(round(total * 50, 0), 0), 100))


def fallback_segment(ds: dict, th: dict, dims: Sequence[str]) -> str:
    n_s = sum(1 for d in dims if _strong(ds, th, d))
    n_w = sum(1 for d in dims if _weak(ds, th, d))
    if n_s >= 5 and n_w == 0:
        return "Cherish"
    if n_s >= 3 and not _weak(ds, th, "Risk") and (_strong(ds, th, "Growth") or _strong(ds, th, "Relationship Depth")):
        return "Grow"
    if (_weak(ds, th, "Risk Adjusted Margin") or _weak(ds, th, "Risk")) and _weak(ds, th, "Volume"):
        return "Monitor"
    return "Maintain"




def clamp_to_range(score: float, segment: str, ranges: Dict[str, Sequence[float]]) -> float:
    # FIX: the original fallback composite ignored the segment's score range, so
    # fallback dealers failed the segment-score consistency test by design.
    lo, hi = ranges.get(segment, (0, 100))
    return float(min(max(score, lo), hi))


def dims_dict(row: pd.Series, dims: Sequence[str]) -> Dict[str, float]:
    return {d: float(row[d]) for d in dims if d in row.index and pd.notna(row[d])}
