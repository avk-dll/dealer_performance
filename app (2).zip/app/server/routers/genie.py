"""Ask Genie: questions in plain language, answered by a Databricks AI/BI Genie
space through the Genie Conversation API. The app only relays the question and
the answer; Genie writes and runs the SQL on the space's tables with the app's
service principal (CAN RUN on the space). Off unless GENIE_SPACE_ID is set."""
import logging
import threading
from datetime import timedelta
from typing import Optional

from fastapi import APIRouter, HTTPException
from pydantic import BaseModel, Field

from .. import settings
from ..common import clean

log = logging.getLogger(__name__)
router = APIRouter(prefix="/api/genie", tags=["genie"])
MAX_ROWS = 200

_client = {"w": None}
_lock = threading.Lock()


def _workspace():
    with _lock:
        if _client["w"] is None:
            from databricks.sdk import WorkspaceClient
            _client["w"] = WorkspaceClient()
        return _client["w"]


class Ask(BaseModel):
    question: str = Field(..., min_length=2, max_length=2000)
    conversation_id: Optional[str] = None


def _table(w, msg) -> Optional[dict]:
    """First rows of the query result, when Genie answered with a query."""
    try:
        res = w.genie.get_message_query_result(msg.space_id, msg.conversation_id, msg.id)
    except Exception as e:  # no query, or result expired
        log.info("Genie query result not available: %s", e)
        return None
    sr = res.statement_response
    if sr is None or sr.manifest is None or sr.manifest.schema is None:
        return None
    cols = [c.name for c in (sr.manifest.schema.columns or [])]
    rows = (sr.result.data_array if sr.result and sr.result.data_array else [])[:MAX_ROWS]
    total = sr.manifest.total_row_count
    return {"columns": cols, "rows": rows, "total_rows": total, "truncated": bool(total and total > len(rows))}


@router.get("/status")
def status() -> dict:
    if not settings.GENIE_SPACE_ID:
        return {"enabled": False, "url": settings.GENIE_URL or None,
                "reason": "Genie is not set up for this app yet (GENIE_SPACE_ID is empty)."}
    return {"enabled": True, "url": settings.GENIE_URL or None, "reason": "ok"}


@router.post("/ask")
def ask(body: Ask) -> dict:
    if not settings.GENIE_SPACE_ID:
        raise HTTPException(503, "Genie is not set up for this app yet. Set GENIE_SPACE_ID in app.yaml and add the Genie space as an app resource.")
    try:
        w = _workspace()
        timeout = timedelta(seconds=settings.GENIE_TIMEOUT_SECONDS)
        if body.conversation_id:
            msg = w.genie.create_message_and_wait(settings.GENIE_SPACE_ID, body.conversation_id, body.question, timeout=timeout)
        else:
            msg = w.genie.start_conversation_and_wait(settings.GENIE_SPACE_ID, body.question, timeout=timeout)
    except Exception as e:
        log.warning("Genie call failed: %s", e)
        raise HTTPException(502, f"Genie could not answer: {str(e).splitlines()[0][:300]}")

    texts, sql, description = [], None, None
    for a in msg.attachments or []:
        if a.text and a.text.content:
            texts.append(a.text.content)
        if a.query:
            sql = a.query.query
            description = a.query.description or a.query.title
    status = msg.status.value if msg.status is not None else None
    return clean({
        "conversation_id": msg.conversation_id, "message_id": msg.id, "status": status,
        "text": "\n\n".join(texts) or None, "description": description, "sql": sql,
        "table": _table(w, msg) if sql else None,
        "error": (msg.error.error if msg.error is not None else None),
    })
