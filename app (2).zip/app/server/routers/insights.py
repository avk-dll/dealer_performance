"""Segment insights. Always available: until the model's segments are
published the views use the current (volume-based) segmentation from the gold
data; published results add the dimension profile, the change from the
current segmentation and the archetypes."""
import pandas as pd
from fastapi import APIRouter, Depends

from ..common import Filters, clean, gold_or_404, group_summary, segments

router = APIRouter(prefix="/api/insights", tags=["insights"])


def _cards(df: pd.DataFrame, col: str) -> dict:
    """Size, share and momentum of each segment next to the portfolio in view."""
    n, tot = len(df), float(df["NBV_EUR"].sum())
    cards = [{"segment": s, **group_summary(df[df[col] == s], tot, n)} for s in segments()]
    rest = df[~df[col].isin(segments())]
    if len(rest):
        cards.append({"segment": "Unassigned", **group_summary(rest, tot, n)})
    return {"cards": cards, "portfolio": group_summary(df, tot, n)}


def _medians(d: pd.DataFrame, metrics: list) -> dict:
    return {m["key"]: (float(d[m["key"]].median()) if len(d) and d[m["key"]].notna().any() else None) for m in metrics}


@router.get("")
def insights(f: Filters = Depends()) -> dict:
    ds = gold_or_404()
    pub = ds.published
    published = pub is not None and len(f.apply(pub.df)) > 0
    table = pub if published else ds.gold
    df = f.apply(table.df)
    col = "segment" if published else "current_segment"
    segs = segments()

    by_market = []
    for mk, d in df.groupby("market"):
        by_market.append({"market": mk, "dealers": int(len(d)), **{s: int((d[col] == s).sum()) for s in segs}})
    by_market.sort(key=lambda r: r["dealers"], reverse=True)

    profiles = [{"segment": s, "dealers": int((df[col] == s).sum()), **_medians(df[df[col] == s], table.metrics)} for s in segs]
    overall = {"segment": "All dealers", "dealers": int(len(df)), **_medians(df, table.metrics)}

    pts = df[["dealer_id", "dealer_name", "market", col, "NBV_EUR", "RAM_per_NBV"]].dropna(subset=["NBV_EUR", "RAM_per_NBV", col])
    if len(pts) > 1500:
        pts = pts.sample(1500, random_state=0)
    scatter = [{"dealer_id": r[0], "name": r[1], "market": r[2], "segment": r[3], "nbv": r[4], "ram_per_nbv": r[5]}
               for r in pts.itertuples(index=False)]

    out = {"basis": "published" if published else "current", "run_timestamp": pub.run_timestamp if published else None,
           "dealers": int(len(df)), "metrics": table.metrics, **_cards(df, col), "by_market": by_market,
           "profiles": profiles, "overall": overall, "scatter": scatter,
           "radar": [], "movement": None, "archetypes": []}

    if published:
        out["radar"] = [{"dimension": dim, **{s: (float(v.median()) if (v := df.loc[df["segment"] == s, f"dim:{dim}"]).notna().any() else None)
                                              for s in segs}} for dim in pub.dimensions]
        known = df[df["current_segment"].notna()]
        matrix = pd.crosstab(known["current_segment"], known["segment"]).reindex(index=segs, columns=segs).fillna(0).astype(int)
        rank = {s: i for i, s in enumerate(segs)}
        o, nw = known["current_segment"].map(rank), known["segment"].map(rank)
        out["movement"] = {"rows": segs, "cols": segs, "values": matrix.values.tolist(),
                           "unchanged": int((o == nw).sum()), "upgraded": int((nw < o).sum()), "downgraded": int((nw > o).sum())}
        if pub.has_archetype:
            ct = pd.crosstab(df["archetype"], df["segment"]).reindex(columns=segs).fillna(0).astype(int)
            out["archetypes"] = sorted(({"archetype": a, **{s: int(r[s]) for s in segs}, "total": int(r.sum())} for a, r in ct.iterrows()),
                                       key=lambda r: r["total"], reverse=True)
    return clean(out)
