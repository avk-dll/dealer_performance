"""Segment prediction with an AI explanation — runs only when requested.
Uses the saved model and the gold features; never trains anything."""
from typing import Dict, Optional

from fastapi import APIRouter, HTTPException
from pydantic import BaseModel, Field

from ..common import clean
from ..engine import predict as engine

router = APIRouter(prefix="/api/predict", tags=["predict"])


class ExistingBody(BaseModel):
    market: str
    dealer_id: str
    refresh: bool = False


class NewBody(BaseModel):
    market: str
    inputs: Dict[str, Optional[float]] = Field(default_factory=dict)


def _run(fn, *args):
    try:
        return clean(fn(*args))
    except engine.NotSupported as e:
        raise HTTPException(422, str(e))
    except KeyError as e:
        raise HTTPException(404, str(e).strip("'\""))
    except ValueError as e:
        raise HTTPException(400, str(e))


@router.post("/dealer")
def predict_dealer(body: ExistingBody) -> dict:
    return _run(engine.predict_existing, body.market, body.dealer_id, body.refresh)


@router.get("/form/{market}")
def form(market: str) -> dict:
    return {"fields": engine.INPUT_FIELDS, "defaults": _run(engine.form_defaults, market)}


@router.post("/new")
def predict_new(body: NewBody) -> dict:
    inputs = {k: v for k, v in body.inputs.items() if v is not None}
    return _run(engine.predict_new, body.market, inputs)
