"""Where the segmentation outputs come from.

The app never computes segments. It reads what the data science pipeline
exported:

  CSV (default)  files dropped into OUTPUT_DIR, named as the pipeline writes them
                   v2_final_all_<ts>.csv, v2_final_<MARKET>_<ts>.csv   (final results)
                   v2_debug_all_<ts>.csv, v2_debug_<MARKET>_<ts>.csv,
                   debug_<MARKET>_<ts>.csv                              (review files)
                 Sub-folders are allowed.
                 Optional reference CSVs in CATALOG_DIR fill missing columns.

  Unity Catalog  tables read through a SQL warehouse (DATA_SOURCE=uc).
"""
from __future__ import annotations

import logging
import re
from dataclasses import dataclass, field
from datetime import datetime, timezone
from pathlib import Path
from typing import List, Optional

import pandas as pd

from . import settings

log = logging.getLogger(__name__)
TS_RE = re.compile(r"(\d{8}_\d{6})")


@dataclass
class Frame:
    name: str                      # file or table name
    kind: str                      # final | debug | catalog
    df: pd.DataFrame
    timestamp: Optional[str]       # pipeline run timestamp (YYYYMMDD_HHMMSS) if known
    scope: str = "all"             # all | <MARKET>
    modified: Optional[str] = None
    origin: str = "csv"
    meta: dict = field(default_factory=dict)


def _kind(name: str) -> str:
    n = name.lower()
    if n.startswith("v2_final") or "final" in n or "results" in n:
        return "final"
    if "debug" in n:
        return "debug"
    return "final"


def _scope(name: str) -> str:
    m = re.match(r"(?:v2_)?(?:final|debug)_(all|[A-Z]{2}_[A-Z]{2,3})_", name)
    return m.group(1) if m else "all"


def _iso(ts: float) -> str:
    return datetime.fromtimestamp(ts, tz=timezone.utc).replace(microsecond=0).isoformat()


def csv_signature() -> tuple:
    """Changes whenever a file is added, removed or replaced (used for cache refresh)."""
    files = []
    for base in (settings.OUTPUT_DIR, settings.CATALOG_DIR):
        if base.exists():
            files += [(str(p), p.stat().st_mtime, p.stat().st_size) for p in base.rglob("*.csv")]
    return tuple(sorted(files))


def read_csv_outputs() -> List[Frame]:
    frames: List[Frame] = []
    if settings.OUTPUT_DIR.exists():
        for p in sorted(settings.OUTPUT_DIR.rglob("*.csv")):
            try:
                df = pd.read_csv(p, low_memory=False)
            except Exception as e:  # unreadable file must not take the app down
                log.warning("Skipping %s: %s", p.name, e)
                continue
            ts = TS_RE.search(p.name)
            frames.append(Frame(
                name=str(p.relative_to(settings.OUTPUT_DIR)).replace("\\", "/"), kind=_kind(p.name), df=df,
                timestamp=ts.group(1) if ts else None, scope=_scope(p.name),
                modified=_iso(p.stat().st_mtime)))
    if settings.CATALOG_DIR.exists():
        for p in sorted(settings.CATALOG_DIR.rglob("*.csv")):
            try:
                frames.append(Frame(name=p.name, kind="catalog", df=pd.read_csv(p, low_memory=False),
                                    timestamp=None, modified=_iso(p.stat().st_mtime)))
            except Exception as e:
                log.warning("Skipping catalog %s: %s", p.name, e)
    return frames


# ── Unity Catalog ────────────────────────────────────────────────────────────

def _parse_tables(spec: str) -> List[str]:
    return [s.strip().rpartition("=")[2] for s in spec.split(",") if s.strip()]


def read_uc_outputs() -> List[Frame]:
    """Read result and catalog tables through a Databricks SQL warehouse.

    In Databricks Apps, add the SQL warehouse as an app resource and expose its
    id as DATABRICKS_WAREHOUSE_ID; the app's service principal needs SELECT on
    the tables.
    """
    from databricks import sql
    from databricks.sdk.core import Config

    if not settings.UC_WAREHOUSE_ID:
        raise RuntimeError("DATA_SOURCE=uc needs DATABRICKS_WAREHOUSE_ID.")
    cfg = Config()
    frames: List[Frame] = []
    with sql.connect(server_hostname=cfg.host, http_path=f"/sql/1.0/warehouses/{settings.UC_WAREHOUSE_ID}",
                     credentials_provider=lambda: cfg.authenticate) as conn:
        for kind, spec in (("final", settings.UC_RESULTS_TABLES), ("catalog", settings.UC_CATALOG_TABLES)):
            for table in _parse_tables(spec):
                with conn.cursor() as cur:
                    cur.execute(f"SELECT * FROM {table}")
                    df = cur.fetchall_arrow().to_pandas()
                ts = None
                if "Pipeline_Timestamp" in df.columns and df["Pipeline_Timestamp"].notna().any():
                    ts = str(df["Pipeline_Timestamp"].dropna().astype(str).max())
                frames.append(Frame(name=table, kind=kind, df=df, timestamp=ts, origin="uc",
                                    modified=datetime.now(timezone.utc).replace(microsecond=0).isoformat()))
    return frames


def read_outputs() -> List[Frame]:
    return read_uc_outputs() if settings.DATA_SOURCE == "uc" else read_csv_outputs()
