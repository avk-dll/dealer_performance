"""Dealer roster and dealer profile. Opening a dealer only reads data; a
prediction runs only when the user asks for one (see predict.py)."""
from typing import Optional

import pandas as pd
from fastapi import APIRouter, Depends, HTTPException, Query

from .. import dataset
from ..common import Filters, clean, gold_or_404, quantiles, verdict

router = APIRouter(prefix="/api/dealers", tags=["dealers"])


@router.get("")
def roster(f: Filters = Depends(), q: Optional[str] = None, limit: int = Query(300, le=3000)) -> dict:
    # The segment filter is global (Filters.segment on segment_view = the published segment once results exist).
    ds = gold_or_404()
    df = f.apply(ds.gold.df)
    pub = ds.published.df[["dealer_id", "market", "segment"]] if ds.published is not None else None
    if pub is not None:
        df = df.drop(columns=["segment"]).merge(pub, on=["dealer_id", "market"], how="left")
    total = len(df)
    if q:
        n = q.strip().lower()
        df = df[df["dealer_id"].astype(str).str.contains(n, regex=False) |
                df["dealer_name"].fillna("").astype(str).str.lower().str.contains(n, regex=False)]
    df = df.sort_values("NBV_EUR", ascending=False)
    rows = [{"dealer_id": r.dealer_id, "dealer_name": r.dealer_name, "market": r.market, "nbv": r.NBV_EUR,
             "nbv_vs_py": r.NBV_vs_PY, "ram_per_nbv": r.RAM_per_NBV, "ram": r.Risk_Adjusted_Margin,
             "segment": r.segment if pub is not None else None}
            for r in df.head(limit).itertuples()]
    medians = ds.gold.df.groupby("market")["RAM_per_NBV"].median()
    for row in rows:
        row["market_ram_per_nbv"] = medians.get(row["market"])
    return clean({"total": total, "matched": int(len(df)), "rows": rows, "published": pub is not None})


@router.get("/{market}/{dealer_id}")
def profile(market: str, dealer_id: str) -> dict:
    ds = gold_or_404()
    g = ds.gold.df
    hit = g[(g["market"] == market) & (g["dealer_id"] == dealer_id)]
    if hit.empty:
        raise HTTPException(404, f"Dealer {dealer_id} not found in {market}")
    r = hit.iloc[0]
    mdf = g[g["market"] == market]

    metrics = []
    for met in ds.gold.metrics:
        k = met["key"]
        q = quantiles(mdf[k])
        metrics.append({**met, "value": r.get(k), "market": q, "verdict": verdict(r.get(k), q, met["favour"])})

    rank = int((mdf["NBV_EUR"] > r["NBV_EUR"]).sum()) + 1 if pd.notna(r["NBV_EUR"]) else None
    peers = mdf[mdf["dealer_id"] != dealer_id].assign(gap=(mdf["NBV_EUR"] - r["NBV_EUR"]).abs()).sort_values("gap").head(5)

    published = None
    if ds.published is not None:
        p = ds.published.df
        ph = p[(p["market"] == market) & (p["dealer_id"] == dealer_id)]
        if not ph.empty:
            x = ph.iloc[0]
            published = {"segment": x["segment"], "confidence": x["confidence"], "rationale": x["rationale"],
                         "archetype": x["archetype"], "source": x["source"], "run_timestamp": ds.published.run_timestamp}

    return clean({
        "dealer": {"dealer_id": r["dealer_id"], "dealer_name": r["dealer_name"], "market": market,
                   "country": r["country"], "business_unit": r["business_unit"]},
        "rank_in_market": rank, "market_size": int(len(mdf)),
        "ram_rank_in_market": int((mdf["Risk_Adjusted_Margin"] > r["Risk_Adjusted_Margin"]).sum()) + 1 if pd.notna(r["Risk_Adjusted_Margin"]) else None,
        "history": [{"year": y, "nbv": r.get(k), "market_median": mdf[k].median()}
                    for y, k in (("Two years ago", "nbv_y3"), ("Prior year", "nbv_y2"), ("Latest year", "nbv_y1"))],
        "metrics": metrics,
        "peers": [{"dealer_id": p.dealer_id, "dealer_name": p.dealer_name, "nbv": p.NBV_EUR,
                   "ram_per_nbv": p.RAM_per_NBV, "ram": p.Risk_Adjusted_Margin, "contracts": p.Distinct_Contracts,
                   "nbv_vs_py": p.NBV_vs_PY, "pd": p.PD_Rate,
                   "segment": p.segment_view if ds.published is not None else None} for p in peers.itertuples()],
        "self": {"nbv": r["NBV_EUR"], "ram_per_nbv": r.get("RAM_per_NBV"), "ram": r.get("Risk_Adjusted_Margin"),
                 "contracts": r.get("Distinct_Contracts"), "nbv_vs_py": r.get("NBV_vs_PY"), "pd": r.get("PD_Rate")},
        "published": published,
    })
