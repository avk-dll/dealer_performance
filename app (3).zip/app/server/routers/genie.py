"""Ask Genie One: plain-language data questions answered by the Databricks-provided
Genie One MCP service (system.ai.genie_one_mcp). No Genie space is needed; Genie One
routes each question to the right Genie agent, dashboards, queries and metric views.

Flow (as in the Databricks guide "Integrating Genie One MCP Server into Databricks Apps"):
  genie_ask(question[, conversation_id])        -> conversation_id, response_id, status
  genie_poll_response(conversation_id, response_id) until the status is final
                                                -> answer text, SQL, deep links
  genie_get_query_result(conversation_id, response_id)
                                                -> columns + rows of the query Genie ran

The app only relays the question and answer. Unity Catalog permissions are enforced by
Databricks for the identity that asks: the app's service principal (GENIE_AUTH=app) or
the viewer (GENIE_AUTH=user, with user authorization enabled on the app)."""
import json
import logging
import os
import threading
import time
from typing import Any, Iterable, List, Optional

from fastapi import APIRouter, HTTPException, Request
from pydantic import BaseModel, Field

from .. import settings
from ..common import clean

log = logging.getLogger(__name__)
router = APIRouter(prefix="/api/genie", tags=["genie"])

MAX_ROWS = 200
DONE = {"completed", "complete", "succeeded", "success", "done", "finished"}
FAILED = {"failed", "error", "cancelled", "canceled", "expired", "query_result_expired"}

_lock = threading.Lock()
_app_client: dict = {"w": None}


class GenieError(Exception):
    pass


class Ask(BaseModel):
    question: str = Field(..., min_length=2, max_length=2000)
    conversation_id: Optional[str] = None


# ── connection ───────────────────────────────────────────────────────────────

def _configured_host() -> str:
    """GENIE_WORKSPACE_HOST from app.yaml, unless it is still the <placeholder>."""
    h = settings.GENIE_WORKSPACE_HOST
    return "" if (not h or "<" in h) else h


def _host(w) -> str:
    # app.yaml value first; else the host of the app's own Databricks credentials
    # (DATABRICKS_HOST, set automatically in Databricks Apps).
    host = (_configured_host()
            or (getattr(getattr(w, "config", None), "host", "") if w is not None else "")
            or os.getenv("DATABRICKS_HOST", ""))
    if not host:
        raise GenieError("The workspace URL is not set. Set GENIE_WORKSPACE_HOST in app.yaml.")
    host = host.strip().rstrip("/")
    return host if host.startswith("http") else f"https://{host}"


def _workspace(user_token: Optional[str] = None):
    """WorkspaceClient for the identity that asks Genie One."""
    from databricks.sdk import WorkspaceClient
    if settings.GENIE_AUTH == "user":
        if not user_token:
            raise GenieError("GENIE_AUTH is 'user' but no user token was forwarded. "
                             "Turn on user authorization for the app, or set GENIE_AUTH to 'app'.")
        return WorkspaceClient(host=_host(None), token=user_token, auth_type="pat")
    with _lock:
        if _app_client["w"] is None:
            host = _configured_host()
            _app_client["w"] = WorkspaceClient(host=host) if host else WorkspaceClient()
        return _app_client["w"]


def server_url(w) -> str:
    return settings.GENIE_MCP_URL or f"{_host(w)}{settings.GENIE_MCP_PATH}"


def _mcp_client(w):
    try:
        from databricks_mcp import DatabricksMCPClient
    except ImportError as e:
        raise GenieError("The Genie One client library is not installed (databricks-mcp). "
                         "Check app/requirements.txt and redeploy.") from e
    return DatabricksMCPClient(server_url=server_url(w), workspace_client=w)


# ── reading MCP tool results ─────────────────────────────────────────────────

def _payload(result) -> dict:
    """A tool result as a dict: structured content if present, else the JSON in its text content."""
    texts = [getattr(c, "text", None) for c in (getattr(result, "content", None) or [])]
    texts = [t for t in texts if t]
    # mcp 1.x uses camelCase fields (isError, structuredContent); mcp 2.x uses snake_case.
    if getattr(result, "is_error", None) or getattr(result, "isError", None):
        raise GenieError(" ".join(texts)[:500] or "Genie One returned an error.")
    sc = getattr(result, "structured_content", None) or getattr(result, "structuredContent", None)
    if isinstance(sc, dict) and sc:
        return sc
    for t in texts:
        try:
            v = json.loads(t)
        except (TypeError, ValueError):
            continue
        if isinstance(v, dict):
            return v
        if isinstance(v, list):
            return {"items": v}
    return {"text": "\n\n".join(texts)} if texts else {}


def _walk(obj: Any) -> Iterable[tuple]:
    """(key, value) pairs of a nested dict/list, breadth-first, so top-level fields
    (e.g. the response status) win over nested ones (e.g. a progress step's status)."""
    level = [obj]
    while level:
        nxt = []
        for node in level:
            if isinstance(node, dict):
                for k, v in node.items():
                    yield k, v
                    nxt.append(v)
            elif isinstance(node, list):
                nxt.extend(node)
        level = nxt


def _first(obj: Any, keys: List[str], kind=str):
    """Value of the first key found, trying the keys in order of preference."""
    pairs = list(_walk(obj))
    for key in keys:
        for k, v in pairs:
            if isinstance(k, str) and k.lower() == key and isinstance(v, kind) and not isinstance(v, bool) and v not in ("", [], {}):
                return v
    return None


def _status(obj: dict) -> str:
    return str(_first(obj, ["status", "state"]) or "").lower()


def _answer(obj: dict) -> Optional[str]:
    text = _first(obj, ["answer", "final_answer", "response_text", "text", "content", "message", "summary"])
    return text if isinstance(text, str) else None


def _links(obj: dict) -> List[dict]:
    """Deep links in the answer: objects with a url (and a title), then plain *_url / *link fields."""
    out, seen = [], set()
    pairs = list(_walk(obj))
    dicts = [obj] + [v for _k, v in pairs if isinstance(v, dict)]
    dicts += [x for _k, v in pairs if isinstance(v, list) for x in v if isinstance(x, dict)]
    for v in dicts:
        if isinstance(v.get("url"), str) and v["url"].startswith("http") and v["url"] not in seen:
            seen.add(v["url"])
            out.append({"title": str(v.get("title") or v.get("name") or v.get("type") or "Open in Databricks"), "url": v["url"]})
    for k, v in pairs:
        if (isinstance(k, str) and k.lower() != "url" and ("link" in k.lower() or "url" in k.lower())
                and isinstance(v, str) and v.startswith("http") and v not in seen):
            seen.add(v)
            out.append({"title": k.replace("_", " "), "url": v})
    return out[:6]


def _table(obj: dict) -> Optional[dict]:
    """Columns + rows from a query result, in whichever common shape Genie One returns them."""
    cols = _first(obj, ["columns", "schema", "column_names"], list)
    rows = _first(obj, ["rows", "data_array", "data", "records"], list)
    if not rows:
        return None
    if cols:
        names = [c.get("name") if isinstance(c, dict) else str(c) for c in cols]
    elif isinstance(rows[0], dict):
        names = list(rows[0].keys())
    else:
        names = [f"col{i + 1}" for i in range(len(rows[0]))]
    grid = [[r.get(n) for n in names] if isinstance(r, dict) else list(r) for r in rows[:MAX_ROWS]]
    total = _first(obj, ["total_row_count", "row_count", "total_rows"], int) or len(rows)
    return {"columns": names, "rows": [[None if v is None else str(v) for v in r] for r in grid],
            "total_rows": total, "truncated": total > len(grid)}


# ── endpoints ────────────────────────────────────────────────────────────────

def ask_genie_one(client, question: str, conversation_id: Optional[str]) -> dict:
    args = {"question": question}
    if conversation_id:
        args["conversation_id"] = conversation_id
    started = _payload(client.call_tool("genie_ask", args))
    conv = _first(started, ["conversation_id"]) or conversation_id
    resp = _first(started, ["response_id", "message_id"])
    if not conv or not resp:
        raise GenieError("Genie One did not return a conversation or response id.")

    ids = {"conversation_id": conv, "response_id": resp}
    state, status = started, _status(started)
    deadline = time.monotonic() + settings.GENIE_TIMEOUT_SECONDS
    while status not in DONE | FAILED:
        if time.monotonic() > deadline:
            try:
                client.call_tool("genie_cancel_response", ids)
            except Exception:  # best effort
                pass
            raise GenieError(f"Genie One did not finish within {settings.GENIE_TIMEOUT_SECONDS} seconds. Try a narrower question.")
        time.sleep(settings.GENIE_POLL_SECONDS)
        state = _payload(client.call_tool("genie_poll_response", ids))
        status = _status(state)

    table = None
    sql = _first(state, ["sql", "query", "sql_query", "statement"])
    if status in DONE:
        try:
            table = _table(_payload(client.call_tool("genie_get_query_result", ids)))
        except Exception as e:  # no query for this answer, or result expired
            log.info("Genie One query result not available: %s", e)
    return {
        **ids, "status": status,
        "text": _answer(state), "sql": sql if isinstance(sql, str) else None,
        "description": _first(state, ["description", "title"]),
        "table": table, "links": _links(state),
        "error": (_first(state, ["error", "error_message"]) or "Genie One could not answer this question.") if status in FAILED else None,
    }


@router.get("/status")
def status() -> dict:
    if not settings.GENIE_ENABLED:
        return {"enabled": False, "url": settings.GENIE_ONE_URL or None, "reason": "Genie One is switched off (GENIE_ENABLED=false)."}
    return {"enabled": True, "url": settings.GENIE_ONE_URL or None, "auth": settings.GENIE_AUTH, "reason": "ok"}


@router.post("/ask")
def ask(body: Ask, request: Request) -> dict:
    if not settings.GENIE_ENABLED:
        raise HTTPException(503, "Genie One is switched off for this app (GENIE_ENABLED=false).")
    try:
        w = _workspace(request.headers.get("x-forwarded-access-token"))
        return clean(ask_genie_one(_mcp_client(w), body.question, body.conversation_id))
    except GenieError as e:
        raise HTTPException(502, str(e))
    except Exception as e:
        log.warning("Genie One call failed: %s", e)
        raise HTTPException(502, f"Genie One could not answer: {str(e).splitlines()[0][:300]}")
