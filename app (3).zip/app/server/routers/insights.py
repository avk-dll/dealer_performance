"""Segment insights for the model's published segments. Before results are
published the page shows a notice only (the current segmentation is not shown)."""
import pandas as pd
from fastapi import APIRouter, Depends

from ..common import Filters, clean, gold_or_404, group_summary, segments

router = APIRouter(prefix="/api/insights", tags=["insights"])


def _cards(df: pd.DataFrame, col: str) -> dict:
    """Size, share and momentum of each segment next to the portfolio in view."""
    n, tot = len(df), float(df["NBV_EUR"].sum())
    cards = [{"segment": s, **group_summary(df[df[col] == s], tot, n)} for s in segments()]
    rest = df[~df[col].isin(segments())]
    if len(rest):
        cards.append({"segment": "Unassigned", **group_summary(rest, tot, n)})
    return {"cards": cards, "portfolio": group_summary(df, tot, n)}


def _medians(d: pd.DataFrame, metrics: list) -> dict:
    return {m["key"]: (float(d[m["key"]].median()) if len(d) and d[m["key"]].notna().any() else None) for m in metrics}


@router.get("")
def insights(f: Filters = Depends()) -> dict:
    ds = gold_or_404()
    pub = ds.published
    if pub is None or len(f.apply(pub.df)) == 0:
        return {"basis": "none", "run_timestamp": None, "dealers": 0, "metrics": [], "cards": [], "portfolio": None,
                "by_market": [], "profiles": [], "overall": None, "scatter": [], "radar": [], "archetypes": []}
    table = pub
    df = f.apply(table.df)
    col = "segment"
    segs = segments()

    by_market = []
    for mk, d in df.groupby("market"):
        by_market.append({"market": mk, "dealers": int(len(d)), **{s: int((d[col] == s).sum()) for s in segs}})
    by_market.sort(key=lambda r: r["dealers"], reverse=True)

    profiles = [{"segment": s, "dealers": int((df[col] == s).sum()), **_medians(df[df[col] == s], table.metrics)} for s in segs]
    overall = {"segment": "All dealers", "dealers": int(len(df)), **_medians(df, table.metrics)}

    pts = df[["dealer_id", "dealer_name", "market", col, "NBV_EUR", "RAM_per_NBV"]].dropna(subset=["NBV_EUR", "RAM_per_NBV", col])
    if len(pts) > 1500:
        pts = pts.sample(1500, random_state=0)
    scatter = [{"dealer_id": r[0], "name": r[1], "market": r[2], "segment": r[3], "nbv": r[4], "ram_per_nbv": r[5]}
               for r in pts.itertuples(index=False)]

    out = {"basis": "published", "run_timestamp": pub.run_timestamp,
           "dealers": int(len(df)), "metrics": table.metrics, **_cards(df, col), "by_market": by_market,
           "profiles": profiles, "overall": overall, "scatter": scatter,
           "radar": [], "archetypes": []}

    out["radar"] = [{"dimension": dim, **{s: (float(v.median()) if (v := df.loc[df["segment"] == s, f"dim:{dim}"]).notna().any() else None)
                                          for s in segs}} for dim in pub.dimensions]
    if pub.has_archetype:
        ct = pd.crosstab(df["archetype"], df["segment"]).reindex(columns=segs).fillna(0).astype(int)
        out["archetypes"] = sorted(({"archetype": a, **{s: int(r[s]) for s in segs}, "total": int(r.sum())} for a, r in ct.iterrows()),
                                   key=lambda r: r["total"], reverse=True)
    return clean(out)
