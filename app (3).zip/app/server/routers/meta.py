"""What is loaded (for the UI shell) — deliberately light on technical detail."""
from fastapi import APIRouter, Request

from .. import dataset, settings
from ..common import clean
from ..engine import model_store

router = APIRouter(prefix="/api", tags=["meta"])


@router.get("/health")
def health() -> dict:
    return {"status": "ok", "version": settings.APP_VERSION}


@router.get("/meta")
def meta(request: Request) -> dict:
    ds = dataset.get()
    c = settings.contract()
    cfg = settings.model_config()
    g = ds.gold.df if ds.gold is not None else None
    p = ds.published
    return clean({
        "app_version": settings.APP_VERSION,
        "model_name": cfg["name"],
        "model_markets": cfg["markets"],
        "min_dealers": cfg["min_dealers"],
        "segments": c["segments"]["order"],
        "segment_definitions": c["segments"]["definitions"],
        "archetypes": cfg.get("archetypes", {}),
        "gold": None if g is None else {
            "dealers": int(len(g)),
            "markets": sorted(g["market"].dropna().unique().tolist()),
            "countries": sorted(g["country"].dropna().astype(str).unique().tolist()),
            "business_units": sorted(g["business_unit"].dropna().astype(str).unique().tolist()),
        },
        "published": None if p is None else {
            "run_timestamp": p.run_timestamp, "dealers": int(len(p.df)),
            "markets": sorted(p.df["market"].dropna().unique().tolist()), "has_archetype": p.has_archetype,
        },
        "model_uploaded": bool(model_store.files()),
        "ai_enabled": settings.USE_LLM,
        "genie": {"enabled": settings.GENIE_ENABLED, "url": settings.GENIE_ONE_URL or None},
        "on_databricks": settings.running_on_databricks(),
        "user": request.headers.get("X-Forwarded-Email") or "",
        "errors": ds.errors,
    })


@router.post("/reload")
def reload() -> dict:
    ds = dataset.reload()
    return {"ok": True, "published": ds.published is not None, "errors": ds.errors}
