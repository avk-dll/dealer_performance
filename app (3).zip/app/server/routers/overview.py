"""Portfolio overview: how the portfolio and each market are performing.
Gold features only, so it is always available. Segment views live in insights.py."""
import pandas as pd
from fastapi import APIRouter, Depends, Query

from ..common import Filters, clean, gold_or_404, group_summary, vs_py

router = APIRouter(prefix="/api/overview", tags=["overview"])

YEARS = (("Two years ago", "nbv_y3"), ("Prior year", "nbv_y2"), ("Latest year", "nbv_y1"))


def _momentum(d: pd.DataFrame, flat: float) -> dict:
    """Dealers growing / flat / declining on the prior year (flat = within ±flat)."""
    v = d["NBV_vs_PY"].dropna()
    n = len(v)
    counts = {"growing": int((v > flat).sum()), "flat": int(v.between(-flat, flat).sum()),
              "declining": int((v < -flat).sum()), "new": int(d["NBV_vs_PY"].isna().sum())}
    return {**counts, **{f"{k}_share": (c / n * 100 if n else None) for k, c in counts.items() if k != "new"}}


def _kpis(df: pd.DataFrame, flat: float) -> dict:
    nbv = df["NBV_EUR"]
    tot = float(nbv.sum())
    return {**group_summary(df, tot, len(df)), "markets": int(df["market"].nunique()),
            "median_cagr": float(df["NBV_CAGR"].median()) if len(df) else None,
            "neg_ram": int((df["Risk_Adjusted_Margin"] < 0).sum()),
            "top10_nbv_share": float(nbv.nlargest(max(1, len(df) // 10)).sum() / tot * 100) if tot else None,
            "momentum": _momentum(df, flat),
            "history": [{"year": y, "nbv": float(df[k].sum())} for y, k in YEARS]}


def _movers(d: pd.DataFrame, n: int, min_nbv: float, published: bool) -> dict:
    """Largest volume change in EUR, among dealers of a meaningful size in either year."""
    x = d[(d["nbv_y2"] >= min_nbv) | (d["nbv_y1"] >= min_nbv)].assign(change=d["nbv_y1"] - d["nbv_y2"]).dropna(subset=["change"])

    def rows(part):
        return [{"dealer_id": r.dealer_id, "dealer_name": r.dealer_name, "market": r.market, "nbv": r.nbv_y1,
                 "nbv_py": r.nbv_y2, "change": r.change, "nbv_vs_py": r.NBV_vs_PY, "ram_per_nbv": r.RAM_per_NBV,
                 "segment": r.segment_view if published else None} for r in part.itertuples()]
    return {"growers": rows(x[x["change"] > 0].nlargest(n, "change")),
            "decliners": rows(x[x["change"] < 0].nsmallest(n, "change")), "min_nbv": min_nbv}


@router.get("")
def overview(f: Filters = Depends(), top: int = Query(10, le=50), mover_min: float = Query(250_000, ge=0),
             flat_pct: float = Query(2.0, ge=0, le=50)) -> dict:
    ds = gold_or_404()
    df = f.apply(ds.gold.df)
    flat = flat_pct / 100
    n, tot = len(df), float(df["NBV_EUR"].sum())

    scorecard = [{"market": mk, **group_summary(d, tot, n), "momentum": _momentum(d, flat)}
                 for mk, d in df.groupby("market")]
    scorecard.sort(key=lambda r: r["nbv"], reverse=True)
    markets = [r["market"] for r in scorecard]
    trend = [{"year": label, "Portfolio": float(df[k].sum()), **{mk: float(d[k].sum()) for mk, d in df.groupby("market")}}
             for label, k in YEARS]

    largest = df.sort_values("NBV_EUR", ascending=False).head(top)
    med = ds.gold.df.groupby("market")["RAM_per_NBV"].median()
    return clean({
        "kpis": _kpis(df, flat), "scorecard": scorecard, "trend": trend, "markets": markets,
        "movers": _movers(df, top, mover_min, ds.published is not None), "flat_pct": flat_pct, "portfolio_vs_py": vs_py(df),
        "top_dealers": [{"dealer_id": r.dealer_id, "dealer_name": r.dealer_name, "market": r.market,
                         "nbv": r.NBV_EUR, "ram": r.Risk_Adjusted_Margin, "ram_per_nbv": r.RAM_per_NBV,
                         "market_ram_per_nbv": med.get(r.market), "nbv_vs_py": r.NBV_vs_PY,
                         "segment": r.segment_view if ds.published is not None else None} for r in largest.itertuples()],
    })
