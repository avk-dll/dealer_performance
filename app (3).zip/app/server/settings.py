"""Runtime settings. Paths are relative to the app folder unless an absolute
path (e.g. a /Volumes/... path) is given through the environment."""
from __future__ import annotations

import json
import os
from functools import lru_cache
from pathlib import Path

APP_ROOT = Path(__file__).resolve().parent.parent
APP_VERSION = "2.1.0"


def _dir(name: str, default: str) -> Path:
    p = Path(os.getenv(name, default))
    return p if p.is_absolute() else APP_ROOT / p


def _flag(name: str, default: bool) -> bool:
    v = os.getenv(name)
    return default if v is None else v.strip().lower() in {"1", "true", "yes", "on"}


# ── Data ─────────────────────────────────────────────────────────────────────
# Gold dealer features: always shown (dealer list, performance metrics) and the
# input for on-demand predictions.
GOLD_PATH = _dir("GOLD_PATH", "data/gold/gold_dealer_features.csv")
# Published segmentation results from the pipeline (shown only once uploaded).
DATA_SOURCE = os.getenv("DATA_SOURCE", "csv").lower()      # csv | uc
OUTPUT_DIR = _dir("OUTPUT_DIR", "data/outputs")
CATALOG_DIR = _dir("CATALOG_DIR", "data/catalog")
# Saved model file(s) from the pipeline (.pkl) — used for predictions only.
MODEL_DIR = _dir("MODEL_DIR", "data/models")

UC_WAREHOUSE_ID = os.getenv("DATABRICKS_WAREHOUSE_ID", "")
UC_RESULTS_TABLES = os.getenv("RESULTS_TABLES", "")
UC_CATALOG_TABLES = os.getenv("CATALOG_TABLES", "")

# ── AI explanation (Databricks Model Serving) ────────────────────────────────
USE_LLM = _flag("USE_LLM", True)
LLM_ENDPOINT = os.getenv("LLM_ENDPOINT") or None

STATIC_DIR = APP_ROOT / "static"
CONTRACT_PATH = APP_ROOT / "config" / "data_contract.json"
MODEL_CONFIG_PATH = APP_ROOT / "config" / "model.json"
PORT = int(os.getenv("DATABRICKS_APP_PORT", os.getenv("PORT", "8000")))
CORS_ORIGINS = [o.strip() for o in os.getenv("CORS_ORIGINS", "http://localhost:5173").split(",") if o.strip()]
LOG_LEVEL = os.getenv("LOG_LEVEL", "INFO")
REFRESH_SECONDS = int(os.getenv("REFRESH_SECONDS", "60"))


@lru_cache(maxsize=1)
def contract() -> dict:
    return json.loads(CONTRACT_PATH.read_text(encoding="utf-8"))


@lru_cache(maxsize=1)
def model_config() -> dict:
    cfg = json.loads(MODEL_CONFIG_PATH.read_text(encoding="utf-8"))
    if LLM_ENDPOINT:
        cfg["llm"]["endpoint"] = LLM_ENDPOINT
    return cfg


def running_on_databricks() -> bool:
    return bool(os.getenv("DATABRICKS_APP_NAME") or os.getenv("DATABRICKS_APP_PORT"))


# ── Genie One (Databricks-provided MCP service system.ai.genie_one_mcp) ──────
# No Genie space is needed: Genie One routes each question to the right Genie
# agent, dashboards, queries and metric views. The MCP service URL is
#   <workspace host>/ai-gateway/mcp-services/system.ai.genie_one_mcp
# The host comes from GENIE_WORKSPACE_HOST, or else from the app's own Databricks
# credentials (DATABRICKS_HOST, set automatically in Databricks Apps).
GENIE_ENABLED = _flag("GENIE_ENABLED", True)
GENIE_WORKSPACE_HOST = os.getenv("GENIE_WORKSPACE_HOST", "").strip().rstrip("/")
GENIE_MCP_PATH = "/ai-gateway/mcp-services/system.ai.genie_one_mcp"
GENIE_MCP_URL = os.getenv("GENIE_MCP_URL", "").strip()        # optional: full URL override
GENIE_ONE_URL = os.getenv("GENIE_ONE_URL", "").strip()        # optional: "Open Genie One" link in the panel
# app  = the app's service principal asks Genie (shared permissions, default)
# user = each viewer's own permissions (needs user authorization enabled on the app)
GENIE_AUTH = os.getenv("GENIE_AUTH", "app").strip().lower()
GENIE_TIMEOUT_SECONDS = int(os.getenv("GENIE_TIMEOUT_SECONDS", "120"))
GENIE_POLL_SECONDS = float(os.getenv("GENIE_POLL_SECONDS", "2"))
