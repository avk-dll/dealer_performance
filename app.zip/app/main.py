"""Dealer Performance — read-only dealer performance and segmentation views.

Databricks Apps runs `python main.py` (see app.yaml). Locally: python main.py
"""
from __future__ import annotations

import logging
import os

import uvicorn
from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import FileResponse, JSONResponse
from fastapi.staticfiles import StaticFiles

from server import settings
from server.routers import dealers, insights, meta, overview, performance, predict

logging.basicConfig(level=settings.LOG_LEVEL, format="%(asctime)s %(levelname)s %(name)s: %(message)s")

app = FastAPI(title="Dealer Performance API", version=settings.APP_VERSION,
              description="Dealer performance, published segments and on-demand segment predictions.")
app.add_middleware(CORSMiddleware, allow_origins=settings.CORS_ORIGINS, allow_credentials=True,
                   allow_methods=["GET", "POST"], allow_headers=["*"])
for r in (meta.router, performance.router, overview.router, insights.router, dealers.router, predict.router):
    app.include_router(r)

_index = settings.STATIC_DIR / "index.html"
if (settings.STATIC_DIR / "assets").exists():
    app.mount("/assets", StaticFiles(directory=settings.STATIC_DIR / "assets"), name="assets")


@app.get("/{full_path:path}", include_in_schema=False)
def spa(full_path: str):
    if full_path.startswith("api/"):
        return JSONResponse({"detail": "Not Found"}, status_code=404)
    candidate = (settings.STATIC_DIR / full_path).resolve()
    if full_path and candidate.is_file() and settings.STATIC_DIR.resolve() in candidate.parents:
        return FileResponse(candidate)
    if _index.exists():
        return FileResponse(_index)
    return JSONResponse({"detail": "UI not built — run `npm run build` in web/."}, status_code=404)


if __name__ == "__main__":
    uvicorn.run("main:app", host="0.0.0.0", port=settings.PORT,
                reload=os.getenv("RELOAD", "false").lower() == "true")
