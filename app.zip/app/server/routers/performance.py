"""Selling parties, segment trends and the advanced-filter options.

Gold features only, so these pages work before any results are uploaded. The
segment shown is the model's published segment when results exist (dealers it
did not segment are "Unassigned"), otherwise the current segmentation.

Time: the gold data holds three 12-month NBV periods per dealer (latest, prior,
two years ago). Every other measure is for the latest period only."""
from typing import List, Optional

import numpy as np
import pandas as pd
from fastapi import APIRouter, Depends, HTTPException, Query

from .. import dataset
from ..common import Filters, clean, gold_or_404, segments

router = APIRouter(prefix="/api", tags=["performance"])

# (key, label, NBV column, prior-period NBV column)
YEARS = [("y1", "Latest year", "nbv_y1", "nbv_y2"), ("y2", "Prior year", "nbv_y2", "nbv_y3"), ("y3", "Two years ago", "nbv_y3", None)]
TREND_METRICS = {"nbv": "NBV amount", "dealers": "Active dealers", "avg_nbv": "Average NBV per active dealer", "nbv_share": "NBV share"}


def _year(key: str):
    for y in YEARS:
        if y[0] == key:
            return y
    raise HTTPException(400, f"Unknown year '{key}'. Use one of {[y[0] for y in YEARS]}.")


def segment_order(df: pd.DataFrame) -> List[str]:
    extra = sorted(s for s in df["segment_view"].dropna().unique() if s not in segments() and s != dataset.UNASSIGNED)
    tail = [dataset.UNASSIGNED] if (df["segment_view"] == dataset.UNASSIGNED).any() else []
    return segments() + extra + tail


def _ratio(a: float, b: float) -> Optional[float]:
    return float(a / b - 1) if b and b > 0 else None


def _card(d: pd.DataFrame, col: str, prev: Optional[str], tot_nbv: float, tot_n: int) -> dict:
    nbv = float(d[col].sum())
    active = int((d[col] > 0).sum())
    return {"dealers": int(len(d)), "active": active, "nbv": nbv,
            "dealer_share": len(d) / tot_n * 100 if tot_n else None,
            "nbv_share": nbv / tot_nbv * 100 if tot_nbv else None,
            "avg_nbv": nbv / active if active else None,
            "nbv_vs_py": _ratio(nbv, float(d[prev].sum())) if prev else None}


def cards(df: pd.DataFrame, year: str) -> dict:
    _, label, col, prev = _year(year)
    tot, n = float(df[col].sum()), len(df)
    return {"year": year, "year_label": label, "has_py": prev is not None,
            "cards": [{"segment": s, **_card(df[df["segment_view"] == s], col, prev, tot, n)} for s in segment_order(df)],
            "total": _card(df, col, prev, tot, n)}


def _basis() -> dict:
    ds = dataset.get()
    return {"basis": "published" if ds.published is not None else "current",
            "run_timestamp": ds.published.run_timestamp if ds.published is not None else None}


def _movers(df: pd.DataFrame, col: str, prev: Optional[str], n: int) -> dict:
    if prev is None:
        return {"growing": [], "declining": []}
    x = df.assign(change=df[col].fillna(0) - df[prev].fillna(0))

    def rows(part):
        return [{"dealer_id": r.dealer_id, "dealer_name": r.dealer_name, "market": r.market, "segment": r.segment_view,
                 "nbv": getattr(r, col), "change": r.change} for r in part.itertuples()]
    return {"growing": rows(x[x["change"] > 0].nlargest(n, "change")),
            "declining": rows(x[x["change"] < 0].nsmallest(n, "change"))}


@router.get("/parties")
def parties(f: Filters = Depends(), year: str = Query("y1"), q: Optional[str] = None) -> dict:
    ds = gold_or_404()
    gold = ds.gold.df
    df = f.apply(gold)
    _, label, col, prev = _year(year)
    out = {**_basis(), **cards(df, year)}
    if q:
        n = q.strip().lower()
        df = df[df["dealer_id"].astype(str).str.contains(n, regex=False) |
                df["dealer_name"].fillna("").astype(str).str.lower().str.contains(n, regex=False)]

    ram_med = gold.groupby("market")["RAM_per_NBV"].median()
    pd_med = gold.groupby("market")["PD_Rate"].median()
    nbv = df["NBV_EUR"].replace(0, np.nan)
    t = pd.DataFrame({
        "dealer_id": df["dealer_id"], "dealer_name": df["dealer_name"], "market": df["market"], "segment": df["segment_view"],
        "nbv": df[col], "nbv_py": df[prev] if prev else np.nan,
        "nbv_vs_py": (df[col] / df[prev].where(df[prev] > 0) - 1) if prev else np.nan,
        "cagr": df["NBV_CAGR"], "contracts": df["Distinct_Contracts"], "avg_deal": df["Avg_Deal_Size"],
        "fmv_share": df["FMV_NBV"] / nbv, "direct_share": df["DealerDirect_NBV"] / nbv,
        "ram": df["Risk_Adjusted_Margin"], "margin": df["RAM_per_NBV"], "margin_mkt": df["market"].map(ram_med),
        "pd": df["PD_Rate"], "pd_mkt": df["market"].map(pd_med), "lgd": df["LGD_Rate"],
        "retention": df["Engagement_Decay"],
    }).sort_values("nbv", ascending=False)

    s_nbv = float(df["NBV_EUR"].sum())
    s_col = float(df[col].sum())
    total = {"dealers": int(len(df)), "nbv": s_col, "nbv_py": float(df[prev].sum()) if prev else None,
             "nbv_vs_py": _ratio(s_col, float(df[prev].sum())) if prev else None,
             "contracts": int(df["Distinct_Contracts"].sum()),
             "avg_deal": s_nbv / df["Distinct_Contracts"].sum() if df["Distinct_Contracts"].sum() else None,
             "fmv_share": df["FMV_NBV"].sum() / s_nbv if s_nbv else None,
             "direct_share": df["DealerDirect_NBV"].sum() / s_nbv if s_nbv else None,
             "ram": float(df["Risk_Adjusted_Margin"].sum()),
             "margin": float(df["Risk_Adjusted_Margin"].sum() / s_nbv) if s_nbv else None,
             "pd": float((df["PD_Rate"] * df["NBV_EUR"]).sum() / s_nbv) if s_nbv else None,     # NBV-weighted
             "lgd": float((df["LGD_Rate"] * df["NBV_EUR"]).sum() / s_nbv) if s_nbv else None,
             "retention": float(df["Engagement_Decay"].median()) if len(df) else None}
    out.update({"rows": t.to_dict(orient="records"), "table_total": total, "matched": int(len(df))})
    return clean(out)


@router.get("/trends")
def trends(f: Filters = Depends(), year: str = Query("y1"), top: int = Query(10, le=50)) -> dict:
    ds = gold_or_404()
    df = f.apply(ds.gold.df)
    _, label, col, prev = _year(year)
    order = segment_order(df)
    series = []
    for key, ylabel, c, _p in reversed(YEARS):
        tot = float(df[c].sum())
        point = {"year": ylabel}
        for s in order:
            d = df[df["segment_view"] == s]
            v, a = float(d[c].sum()), int((d[c] > 0).sum())
            point[s] = {"nbv": v, "dealers": a, "avg_nbv": v / a if a else None, "nbv_share": v / tot * 100 if tot else None}
        series.append(point)
    return clean({**_basis(), **cards(df, year), "series": series, "segments": order,
                  "metrics": TREND_METRICS, "movers": _movers(df, col, prev, top)})


@router.get("/advanced")
def advanced(f: Filters = Depends()) -> dict:
    """Options for the Advanced Filters page and how many dealers match the current filters."""
    ds = gold_or_404()
    g = ds.gold.df
    plist = g.sort_values("dealer_name", key=lambda s: s.fillna("").str.lower())
    return clean({**_basis(), "matching": int(len(f.apply(g))), "total": int(len(g)),
                  "segments": segment_order(g), "momentum": ["Growing", "Flat", "Declining", "New"],
                  "flat_pct": dataset.FLAT_BAND * 100, "years": [{"key": k, "label": lbl, "has_py": p is not None} for k, lbl, _c, p in YEARS],
                  "parties": [{"key": r.party_key, "dealer_id": r.dealer_id, "name": r.dealer_name or r.dealer_id, "market": r.market}
                              for r in plist.itertuples()]})
